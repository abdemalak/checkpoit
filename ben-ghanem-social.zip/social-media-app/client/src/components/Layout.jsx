import { Compass, House, LogOut, MessageCircle, Moon, Search, Settings, Sun, User } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useSocketEvent } from '../context/SocketContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { api } from '../lib/api.js';
import Avatar from './Avatar.jsx';
import { Logo } from './ui.jsx';
import WhoToFollow from './WhoToFollow.jsx';

function useUnreadCount() {
  const [count, setCount] = useState(0);
  const { pathname } = useLocation();

  const refresh = useCallback(() => {
    api('/conversations/unread-count')
      .then((res) => setCount(res.count))
      .catch(() => {});
  }, []);

  useEffect(refresh, [refresh, pathname]);
  useSocketEvent('message:new', refresh);
  useEffect(() => {
    window.addEventListener('benghanem:messages-read', refresh);
    return () => window.removeEventListener('benghanem:messages-read', refresh);
  }, [refresh]);

  useEffect(() => {
    document.title = count ? `(${count}) Ben Ghanem` : 'Ben Ghanem';
  }, [count]);

  return count;
}

export default function Layout() {
  const { user, logout } = useAuth();
  const { resolved, toggle } = useTheme();
  const { pathname } = useLocation();
  const unread = useUnreadCount();
  const wide = pathname.startsWith('/messages');

  const nav = [
    { to: '/', label: 'Home', icon: House, end: true },
    { to: '/explore', label: 'Explore', icon: Compass },
    { to: '/messages', label: 'Messages', icon: MessageCircle, badge: unread },
    { to: `/u/${user.username}`, label: 'Profile', icon: User },
    { to: '/settings', label: 'Settings', icon: Settings },
  ];
  const ThemeIcon = resolved === 'dark' ? Sun : Moon;
  const themeLabel = resolved === 'dark' ? 'Light mode' : 'Dark mode';
  const badgeText = unread > 99 ? '99+' : unread;

  return (
    <div className={`shell ${wide ? 'shell--wide' : ''}`}>
      <a href="#main" className="skip-link">Skip to content</a>

      <aside className="sidebar">
        <Link to="/" className="brand" aria-label="Ben Ghanem home">
          <Logo size={34} />
          <span className="brand-name">Ben Ghanem</span>
        </Link>
        <nav className="nav" aria-label="Main">
          {nav.map(({ to, label, icon: Icon, end, badge }) => (
            <NavLink key={label} to={to} end={end} className="nav-link" title={label}>
              <Icon size={22} aria-hidden="true" />
              <span className="nav-label">{label}</span>
              {badge > 0 && <span className="badge" aria-label={`${badge} unread`}>{badgeText}</span>}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <button type="button" className="nav-link" onClick={toggle} title={themeLabel}>
            <ThemeIcon size={22} aria-hidden="true" />
            <span className="nav-label">{themeLabel}</span>
          </button>
          <div className="me-card">
            <Link to={`/u/${user.username}`} className="me-card-link" title="Your profile">
              <Avatar user={user} size={40} />
              <span className="me-card-text">
                <span className="strong truncate">{user.name}</span>
                <span className="muted small truncate">@{user.username}</span>
              </span>
            </Link>
            <button type="button" className="icon-btn me-card-logout" onClick={logout} aria-label="Log out" title="Log out">
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </aside>

      <header className="mobile-header">
        <Link to="/" className="brand brand-sm" aria-label="Ben Ghanem home">
          <Logo size={28} />
          <span>Ben Ghanem</span>
        </Link>
        <div className="mobile-header-actions">
          <button type="button" className="icon-btn" onClick={toggle} aria-label={themeLabel}>
            <ThemeIcon size={20} />
          </button>
          <Link to="/settings" className="icon-btn" aria-label="Settings">
            <Settings size={20} />
          </Link>
        </div>
      </header>

      <main id="main" className="main">
        <Outlet />
      </main>

      {!wide && (
        <aside className="aside" aria-label="Discover">
          <SearchBox />
          <WhoToFollow />
          <footer className="aside-footer">Ben Ghanem · React, Node.js, Express, MongoDB & Socket.io</footer>
        </aside>
      )}

      <nav className="tabbar" aria-label="Main">
        {nav
          .filter((item) => item.label !== 'Settings')
          .map(({ to, label, icon: Icon, end, badge }) => (
            <NavLink key={label} to={to} end={end} className="tab-link" aria-label={label}>
              <Icon size={24} aria-hidden="true" />
              {badge > 0 && <span className="badge">{badgeText}</span>}
            </NavLink>
          ))}
      </nav>
    </div>
  );
}

function SearchBox() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  return (
    <form
      className="search-box"
      role="search"
      onSubmit={(e) => {
        e.preventDefault();
        const q = query.trim();
        navigate(q ? `/explore?q=${encodeURIComponent(q)}` : '/explore');
        setQuery('');
      }}
    >
      <Search size={18} aria-hidden="true" />
      <input
        className="input"
        type="search"
        placeholder="Search people"
        aria-label="Search people"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
    </form>
  );
}
