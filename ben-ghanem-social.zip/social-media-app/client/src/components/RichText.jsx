import { Link } from 'react-router-dom';

// Links (http/https) and @mentions. The lookbehind keeps emails like a@b.com from becoming mentions.
const TOKENS = /(https?:\/\/[^\s<]+)|((?<![\w@])@[a-z0-9_]{3,20})/gi;

/** Renders user text with clickable links and @mentions (React escapes everything else). */
export default function RichText({ text = '' }) {
  const parts = [];
  let last = 0;

  for (const match of text.matchAll(TOKENS)) {
    if (match.index > last) parts.push(text.slice(last, match.index));
    const [token, url, mention] = match;

    if (url) {
      const trailing = url.match(/[).,!?;:'"]+$/)?.[0] ?? '';
      const href = url.slice(0, url.length - trailing.length);
      parts.push(
        <a key={match.index} href={href} target="_blank" rel="noopener noreferrer nofollow">
          {href.replace(/^https?:\/\//, '')}
        </a>,
      );
      if (trailing) parts.push(trailing);
    } else if (mention) {
      parts.push(
        <Link key={match.index} to={`/u/${mention.slice(1).toLowerCase()}`}>
          {mention}
        </Link>,
      );
    }
    last = match.index + token.length;
  }
  if (last < text.length) parts.push(text.slice(last));

  return <>{parts}</>;
}
