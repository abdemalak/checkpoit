import { CircleAlert } from 'lucide-react';
import { useEffect, useRef } from 'react';
import PostCard from './PostCard.jsx';
import { EmptyState, PostSkeleton, Spinner } from './ui.jsx';

/** Renders a paginated list of posts from usePaginated(). */
export default function PostList({ pager, empty }) {
  const { items, setItems, loading, loadingMore, error, hasMore, loadMore, reload } = pager;

  if (loading) {
    return (
      <div className="stack">
        <PostSkeleton />
        <PostSkeleton />
        <PostSkeleton />
      </div>
    );
  }

  if (error && !items.length) {
    return (
      <div className="card">
        <EmptyState
          icon={CircleAlert}
          title="Couldn’t load posts"
          action={<button type="button" className="btn btn-secondary" onClick={reload}>Try again</button>}
        >
          {error}
        </EmptyState>
      </div>
    );
  }

  if (!items.length) return empty ?? null;

  return (
    <div className="stack">
      {items.map((post) => (
        <PostCard
          key={post.id}
          post={post}
          onDeleted={(id) => setItems((list) => list.filter((p) => p.id !== id))}
        />
      ))}
      {hasMore && <LoadMore onLoad={loadMore} loading={loadingMore} />}
      {!hasMore && items.length > 3 && <p className="list-end">You’re all caught up ✨</p>}
    </div>
  );
}

/** Loads the next page automatically when scrolled into view (with a button fallback). */
function LoadMore({ onLoad, loading }) {
  const ref = useRef(null);
  const onLoadRef = useRef(onLoad);
  useEffect(() => {
    onLoadRef.current = onLoad;
  });

  useEffect(() => {
    const el = ref.current;
    if (!el || !('IntersectionObserver' in window)) return undefined;
    const observer = new IntersectionObserver(
      ([entry]) => entry.isIntersecting && onLoadRef.current(),
      { rootMargin: '400px' },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className="center">
      <button type="button" className="btn btn-secondary" onClick={onLoad} disabled={loading}>
        {loading ? <Spinner size={16} /> : 'Load more'}
      </button>
    </div>
  );
}
