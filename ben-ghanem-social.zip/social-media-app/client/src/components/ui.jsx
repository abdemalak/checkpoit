// Small building blocks used across pages.
import { ArrowLeft, LoaderCircle } from 'lucide-react';
import { useId } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export function Logo({ size = 32 }) {
  const id = useId();
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5b49f0" />
          <stop offset="1" stopColor="#e5569b" />
        </linearGradient>
      </defs>
      <circle cx="16" cy="16" r="8.5" fill={`url(#${id})`} />
      <ellipse
        cx="16" cy="16" rx="14.5" ry="5.2" fill="none"
        stroke={`url(#${id})`} strokeWidth="2.2" transform="rotate(-24 16 16)"
      />
      <circle cx="28" cy="10.6" r="2.2" fill="#e5569b" />
    </svg>
  );
}

export function Spinner({ size = 20, label = 'Loading' }) {
  return <LoaderCircle className="spinner" size={size} role="status" aria-label={label} />;
}

export function EmptyState({ icon: Icon, title, children, action }) {
  return (
    <div className="empty">
      {Icon && (
        <div className="empty-icon">
          <Icon size={26} aria-hidden="true" />
        </div>
      )}
      <h3>{title}</h3>
      {children && <p>{children}</p>}
      {action}
    </div>
  );
}

export function Field({ id, label, error, hint, counter, children }) {
  return (
    <div className="field">
      <div className="field-label-row">
        <label htmlFor={id}>{label}</label>
        {counter && <span className="field-counter">{counter}</span>}
      </div>
      {children}
      {error ? (
        <div className="field-error" id={`${id}-error`}>{error}</div>
      ) : (
        hint && <div className="field-hint" id={`${id}-hint`}>{hint}</div>
      )}
    </div>
  );
}

export function PageHeader({ title, subtitle, back = false, children }) {
  const navigate = useNavigate();
  const location = useLocation();
  // location.key is "default" when the page was opened directly (no in-app history).
  const goBack = () => (location.key === 'default' ? navigate('/') : navigate(-1));
  return (
    <header className="page-header">
      {back && (
        <button type="button" className="icon-btn" onClick={goBack} aria-label="Go back">
          <ArrowLeft size={20} />
        </button>
      )}
      <div className="min-w-0">
        <h1 className="truncate">{title}</h1>
        {subtitle && <div className="page-subtitle truncate">{subtitle}</div>}
      </div>
      {children}
    </header>
  );
}

export function PostSkeleton() {
  return (
    <div className="card post" aria-hidden="true">
      <div className="skeleton circle" style={{ width: 44, height: 44 }} />
      <div className="stack-sm">
        <div className="skeleton" style={{ width: '38%', height: 14 }} />
        <div className="skeleton" style={{ width: '92%', height: 14 }} />
        <div className="skeleton" style={{ width: '64%', height: 14 }} />
      </div>
    </div>
  );
}

/** Grows a textarea to fit its content. */
export function autosize(el) {
  if (!el) return;
  el.style.height = 'auto';
  el.style.height = `${el.scrollHeight}px`;
}
