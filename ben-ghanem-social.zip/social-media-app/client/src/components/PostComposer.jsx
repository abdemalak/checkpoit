import { ImagePlus, X } from 'lucide-react';
import { useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { api } from '../lib/api.js';
import Avatar from './Avatar.jsx';
import { autosize, Spinner } from './ui.jsx';

const MAX_LENGTH = 1000;
const isHttpUrl = (value) => /^https?:\/\/\S+$/i.test(value);

export default function PostComposer({ onPosted }) {
  const { user } = useAuth();
  const toast = useToast();
  const [text, setText] = useState('');
  const [image, setImage] = useState('');
  const [showImage, setShowImage] = useState(false);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState('');
  const textRef = useRef(null);

  const remaining = MAX_LENGTH - text.length;
  const imageValue = showImage ? image.trim() : '';
  const imageInvalid = Boolean(imageValue) && !isHttpUrl(imageValue);
  const canPost = Boolean(text.trim() || imageValue) && remaining >= 0 && !imageInvalid && !posting;

  async function submit(e) {
    e?.preventDefault();
    if (!canPost) return;
    setPosting(true);
    setError('');
    try {
      const { post } = await api('/posts', { method: 'POST', body: { text, image: imageValue } });
      onPosted(post);
      setText('');
      setImage('');
      setShowImage(false);
      if (textRef.current) textRef.current.style.height = '';
      toast.success('Posted');
    } catch (err) {
      setError(err.message);
    } finally {
      setPosting(false);
    }
  }

  return (
    <form className="card composer" onSubmit={submit}>
      <Avatar user={user} />
      <div className="composer-main">
        <label htmlFor="composer-text" className="sr-only">Write a post</label>
        <textarea
          id="composer-text"
          ref={textRef}
          rows={2}
          placeholder={`What’s on your mind, ${user.name.split(' ')[0]}?`}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            autosize(e.target);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submit(e);
          }}
        />

        {showImage && (
          <div className="composer-image">
            <div className="input-with-action">
              <input
                className="input"
                type="url"
                inputMode="url"
                placeholder="Paste an image link (https://…)"
                aria-label="Image link"
                aria-invalid={imageInvalid}
                value={image}
                onChange={(e) => setImage(e.target.value)}
                autoFocus
              />
              <button
                type="button"
                className="icon-btn icon-btn-sm"
                onClick={() => {
                  setShowImage(false);
                  setImage('');
                }}
                aria-label="Remove image"
              >
                <X size={16} />
              </button>
            </div>
            {imageInvalid && <div className="field-error">Image links must start with http:// or https://</div>}
            {imageValue && !imageInvalid && <ImagePreview key={imageValue} src={imageValue} />}
          </div>
        )}

        {error && <div className="alert alert-error" role="alert">{error}</div>}

        <div className="composer-footer">
          <button
            type="button"
            className={`icon-btn icon-btn-brand ${showImage ? 'active' : ''}`}
            onClick={() => setShowImage((open) => !open)}
            aria-pressed={showImage}
            aria-label="Add an image link"
            title="Add an image link"
          >
            <ImagePlus size={20} />
          </button>
          <div className="composer-submit">
            {text.length > 0 && (
              <span
                className={`char-count ${remaining < 0 ? 'over' : remaining <= 100 ? 'warn' : ''}`}
                aria-label={`${remaining} characters left`}
              >
                {remaining}
              </span>
            )}
            <button type="submit" className="btn btn-primary" disabled={!canPost}>
              {posting ? <Spinner size={16} label="Posting" /> : 'Post'}
            </button>
          </div>
        </div>
      </div>
    </form>
  );
}

function ImagePreview({ src }) {
  const [failed, setFailed] = useState(false);
  if (failed) return <div className="field-hint">We couldn’t load a preview for that link.</div>;
  return (
    <img className="post-image composer-preview" src={src} alt="Preview" referrerPolicy="no-referrer" onError={() => setFailed(true)} />
  );
}
