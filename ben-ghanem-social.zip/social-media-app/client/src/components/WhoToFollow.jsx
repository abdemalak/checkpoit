import { useEffect, useState } from 'react';
import { api } from '../lib/api.js';
import UserRow from './UserRow.jsx';

/** Suggested people the user doesn't follow yet. Renders nothing when there are none. */
export default function WhoToFollow({ onFollowChange, plain = false }) {
  const [users, setUsers] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api('/users/suggestions')
      .then((res) => !cancelled && setUsers(res.users))
      .catch(() => !cancelled && setUsers([]));
    return () => {
      cancelled = true;
    };
  }, []);

  if (!users?.length) return null;

  const list = (
    <>
      <h2 className="card-title">Who to follow</h2>
      <div className="user-list">
        {users.map((user) => (
          <UserRow key={user.id} user={user} showBio={false} onFollowChange={onFollowChange} />
        ))}
      </div>
    </>
  );
  return plain ? <div className="who-to-follow">{list}</div> : <section className="card who-to-follow">{list}</section>;
}
