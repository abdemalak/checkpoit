import { useEffect, useState } from 'react';
import { useToast } from '../context/ToastContext.jsx';
import { api } from '../lib/api.js';

export const FOLLOW_EVENT = 'benghanem:follow-change';

/** Listens for follow/unfollow of any user anywhere on the page. */
export function useFollowChanges(handler) {
  useEffect(() => {
    const listener = (e) => handler(e.detail);
    window.addEventListener(FOLLOW_EVENT, listener);
    return () => window.removeEventListener(FOLLOW_EVENT, listener);
  }, [handler]);
}

/** Follow / Following toggle. Give it key={user.id} so it resets for a different user. */
export default function FollowButton({ user, onChange, small = false }) {
  const toast = useToast();
  const [following, setFollowing] = useState(user.isFollowing);
  const [busy, setBusy] = useState(false);
  const [hovered, setHovered] = useState(false);

  // Keep every button for the same person in sync (e.g. profile header and sidebar).
  useEffect(() => {
    const listener = (e) => {
      if (e.detail.userId === user.id) setFollowing(e.detail.following);
    };
    window.addEventListener(FOLLOW_EVENT, listener);
    return () => window.removeEventListener(FOLLOW_EVENT, listener);
  }, [user.id]);

  if (user.isMe) return null;

  async function toggle() {
    setBusy(true);
    try {
      const result = await api(`/users/${user.id}/follow`, { method: following ? 'DELETE' : 'POST' });
      setFollowing(result.following);
      onChange?.(result);
      window.dispatchEvent(new CustomEvent(FOLLOW_EVENT, { detail: { userId: user.id, ...result } }));
    } catch (err) {
      toast.error(err.message);
    } finally {
      setBusy(false);
    }
  }

  const label = following ? (hovered ? 'Unfollow' : 'Following') : 'Follow';
  return (
    <button
      type="button"
      className={`btn ${following ? 'btn-secondary btn-following' : 'btn-primary'} ${small ? 'btn-sm' : ''}`}
      onClick={toggle}
      disabled={busy}
      aria-pressed={following}
      aria-label={following ? `Unfollow ${user.name}` : `Follow ${user.name}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {label}
    </button>
  );
}
