import { Heart, MessageCircle, Send, Trash2 } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { api } from '../lib/api.js';
import { fullDate, timeAgo } from '../lib/time.js';
import Avatar from './Avatar.jsx';
import RichText from './RichText.jsx';

export default function PostCard({ post, onDeleted }) {
  const { user: me } = useAuth();
  const toast = useToast();
  const [liked, setLiked] = useState(post.liked);
  const [likesCount, setLikesCount] = useState(post.likesCount);
  const [comments, setComments] = useState(post.comments);
  const [showComments, setShowComments] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [popKey, setPopKey] = useState(0);

  const profileUrl = `/u/${post.author.username}`;
  const isMine = me.id === post.author.id;

  async function toggleLike() {
    const next = !liked;
    // Update instantly, then reconcile with the server's answer.
    setLiked(next);
    setLikesCount((count) => count + (next ? 1 : -1));
    if (next) setPopKey((k) => k + 1);
    try {
      const result = await api(`/posts/${post.id}/like`, { method: next ? 'POST' : 'DELETE' });
      setLiked(result.liked);
      setLikesCount(result.likesCount);
    } catch (err) {
      setLiked(!next);
      setLikesCount((count) => count + (next ? -1 : 1));
      toast.error(err.message);
    }
  }

  async function remove() {
    if (!window.confirm('Delete this post? This can’t be undone.')) return;
    setDeleting(true);
    try {
      await api(`/posts/${post.id}`, { method: 'DELETE' });
      onDeleted?.(post.id);
      toast.success('Post deleted');
    } catch (err) {
      toast.error(err.message);
      setDeleting(false);
    }
  }

  return (
    <article className={`card post ${deleting ? 'is-busy' : ''}`}>
      <Link to={profileUrl} tabIndex={-1} aria-hidden="true">
        <Avatar user={post.author} />
      </Link>

      <div className="post-main">
        <header className="post-head">
          <Link to={profileUrl} className="post-name truncate">{post.author.name}</Link>
          <span className="post-handle truncate">@{post.author.username}</span>
          <span className="post-dot" aria-hidden="true">·</span>
          <time className="post-time" dateTime={post.createdAt} title={fullDate(post.createdAt)}>
            {timeAgo(post.createdAt)}
          </time>
          {isMine && (
            <button
              type="button"
              className="icon-btn icon-btn-sm post-delete"
              onClick={remove}
              disabled={deleting}
              aria-label="Delete post"
              title="Delete post"
            >
              <Trash2 size={16} />
            </button>
          )}
        </header>

        {post.text && (
          <p className="post-text">
            <RichText text={post.text} />
          </p>
        )}
        {post.image && !imageFailed && (
          <img
            className="post-image"
            src={post.image}
            alt=""
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImageFailed(true)}
          />
        )}

        <div className="post-actions">
          <button
            type="button"
            className={`action action-like ${liked ? 'liked' : ''}`}
            onClick={toggleLike}
            aria-pressed={liked}
            aria-label={`${liked ? 'Unlike' : 'Like'} (${likesCount} likes)`}
          >
            <Heart size={18} key={popKey} className={popKey && liked ? 'pop' : ''} />
            <span>{likesCount}</span>
          </button>
          <button
            type="button"
            className={`action ${showComments ? 'active' : ''}`}
            onClick={() => setShowComments((open) => !open)}
            aria-expanded={showComments}
            aria-label={`Comments (${comments.length})`}
          >
            <MessageCircle size={18} />
            <span>{comments.length}</span>
          </button>
        </div>

        {showComments && (
          <Comments
            postId={post.id}
            postAuthorId={post.author.id}
            comments={comments}
            setComments={setComments}
          />
        )}
      </div>
    </article>
  );
}

function Comments({ postId, postAuthorId, comments, setComments }) {
  const { user: me } = useAuth();
  const toast = useToast();
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  async function submit(e) {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    setSending(true);
    try {
      const { comment } = await api(`/posts/${postId}/comments`, { method: 'POST', body: { text: value } });
      setComments((list) => [...list, comment]);
      setText('');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSending(false);
    }
  }

  async function remove(commentId) {
    try {
      await api(`/posts/${postId}/comments/${commentId}`, { method: 'DELETE' });
      setComments((list) => list.filter((c) => c.id !== commentId));
    } catch (err) {
      toast.error(err.message);
    }
  }

  return (
    <div className="comments">
      {comments.map((comment) => (
        <div className="comment" key={comment.id}>
          <Link to={`/u/${comment.author.username}`} tabIndex={-1} aria-hidden="true">
            <Avatar user={comment.author} size={32} />
          </Link>
          <div className="min-w-0">
            <div className="comment-bubble">
              <Link to={`/u/${comment.author.username}`} className="comment-author">
                {comment.author.name}
              </Link>
              <p className="comment-text">
                <RichText text={comment.text} />
              </p>
            </div>
            <div className="comment-meta">
              <time dateTime={comment.createdAt} title={fullDate(comment.createdAt)}>
                {timeAgo(comment.createdAt)}
              </time>
              {(comment.author.id === me.id || postAuthorId === me.id) && (
                <button type="button" className="link-btn" onClick={() => remove(comment.id)}>
                  Delete
                </button>
              )}
            </div>
          </div>
        </div>
      ))}

      <form className="comment-form" onSubmit={submit}>
        <Avatar user={me} size={32} />
        <input
          ref={inputRef}
          className="input input-pill"
          placeholder="Write a comment…"
          aria-label="Write a comment"
          value={text}
          maxLength={500}
          onChange={(e) => setText(e.target.value)}
        />
        <button
          type="submit"
          className="icon-btn icon-btn-brand"
          disabled={!text.trim() || sending}
          aria-label="Post comment"
        >
          <Send size={17} />
        </button>
      </form>
    </div>
  );
}
