import { Link } from 'react-router-dom';
import Avatar from './Avatar.jsx';
import FollowButton from './FollowButton.jsx';

export default function UserRow({ user, showBio = true, onFollowChange }) {
  const profileUrl = `/u/${user.username}`;
  return (
    <div className="user-row">
      <Link to={profileUrl} tabIndex={-1} aria-hidden="true">
        <Avatar user={user} size={44} />
      </Link>
      <Link to={profileUrl} className="user-row-text">
        <span className="user-row-name truncate">{user.name}</span>
        <span className="user-row-handle truncate">@{user.username}</span>
        {showBio && user.bio && <span className="user-row-bio">{user.bio}</span>}
      </Link>
      <FollowButton key={user.id} user={user} small onChange={onFollowChange} />
    </div>
  );
}
