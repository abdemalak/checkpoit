import { useState } from 'react';

const COLORS = ['#5b49f0', '#d6336c', '#0c8599', '#e8590c', '#1c7ed6', '#9c36b5', '#2b8a3e', '#c2255c'];

function colorFor(seed = '') {
  let hash = 0;
  for (const ch of seed) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return COLORS[hash % COLORS.length];
}

function initials(name = '') {
  const letters = name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '');
  return letters.join('') || '?';
}

/** Shows the user's photo, or colored initials when there is none or it fails to load. */
export default function Avatar({ user, size = 44, className = '' }) {
  const [failedSrc, setFailedSrc] = useState(null);
  const src = user?.avatar;
  const style = { width: size, height: size, fontSize: Math.round(size * 0.38) };

  if (src && failedSrc !== src) {
    return (
      <img
        className={`avatar ${className}`}
        src={src}
        alt=""
        style={style}
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={() => setFailedSrc(src)}
      />
    );
  }
  return (
    <span
      className={`avatar avatar-initials ${className}`}
      aria-hidden="true"
      style={{ ...style, background: colorFor(user?.username) }}
    >
      {initials(user?.name)}
    </span>
  );
}

/** A soft gradient for profile covers, stable per username. */
export function coverFor(username = '') {
  const a = colorFor(username);
  const b = colorFor(`${username}-cover`);
  return `linear-gradient(120deg, ${a}, ${b === a ? '#e5569b' : b})`;
}
