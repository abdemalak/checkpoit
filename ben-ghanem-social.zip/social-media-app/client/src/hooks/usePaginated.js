import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Loads a cursor-paginated list. `fetchPage(cursor)` must resolve to
 * { items, nextCursor }. The list reloads whenever `key` changes.
 */
export function usePaginated(fetchPage, key) {
  const [items, setItems] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState('');
  const [reloadCount, setReloadCount] = useState(0);

  const fetchRef = useRef(fetchPage);
  const busyRef = useRef(false);
  useEffect(() => {
    fetchRef.current = fetchPage;
  });

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    fetchRef
      .current(null)
      .then((page) => {
        if (cancelled) return;
        setItems(page.items);
        setCursor(page.nextCursor);
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [key, reloadCount]);

  const loadMore = useCallback(async () => {
    if (!cursor || busyRef.current) return;
    busyRef.current = true;
    setLoadingMore(true);
    try {
      const page = await fetchRef.current(cursor);
      setItems((prev) => {
        const seen = new Set(prev.map((item) => item.id));
        return [...prev, ...page.items.filter((item) => !seen.has(item.id))];
      });
      setCursor(page.nextCursor);
    } catch (err) {
      setError(err.message);
    } finally {
      busyRef.current = false;
      setLoadingMore(false);
    }
  }, [cursor]);

  const reload = useCallback(() => setReloadCount((n) => n + 1), []);

  return { items, setItems, loading, loadingMore, error, hasMore: Boolean(cursor), loadMore, reload };
}
