import { Sparkles } from 'lucide-react';
import { useCallback, useState } from 'react';
import { Link } from 'react-router-dom';
import PostComposer from '../components/PostComposer.jsx';
import PostList from '../components/PostList.jsx';
import { EmptyState, PageHeader } from '../components/ui.jsx';
import WhoToFollow from '../components/WhoToFollow.jsx';
import { usePaginated } from '../hooks/usePaginated.js';
import { api, withCursor } from '../lib/api.js';

export default function Feed() {
  const [refreshKey, setRefreshKey] = useState(0);
  const fetchFeed = useCallback(
    (cursor) =>
      api(withCursor('/posts/feed', cursor)).then((res) => ({ items: res.posts, nextCursor: res.nextCursor })),
    [],
  );
  const pager = usePaginated(fetchFeed, refreshKey);

  return (
    <>
      <PageHeader title="Home" />
      <div className="stack">
        <PostComposer onPosted={(post) => pager.setItems((list) => [post, ...list])} />
        <PostList
          pager={pager}
          empty={
            <div className="card">
              <EmptyState
                icon={Sparkles}
                title="Your feed is quiet"
                action={<Link to="/explore" className="btn btn-secondary">Explore posts</Link>}
              >
                Follow a few people and their posts will show up here.
              </EmptyState>
              {/* Following someone from here reloads the feed with their posts. */}
              <WhoToFollow plain onFollowChange={() => setRefreshKey((k) => k + 1)} />
            </div>
          }
        />
      </div>
    </>
  );
}
