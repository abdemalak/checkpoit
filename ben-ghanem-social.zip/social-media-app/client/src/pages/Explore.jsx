import { Compass, Search, Users } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import PostList from '../components/PostList.jsx';
import { EmptyState, PageHeader, Spinner } from '../components/ui.jsx';
import UserRow from '../components/UserRow.jsx';
import WhoToFollow from '../components/WhoToFollow.jsx';
import { usePaginated } from '../hooks/usePaginated.js';
import { api, withCursor } from '../lib/api.js';

export default function Explore() {
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const [input, setInput] = useState(q);
  const [results, setResults] = useState(null);
  const [searchError, setSearchError] = useState('');

  // Keep the box in sync when the query changes from elsewhere (e.g. the sidebar search).
  useEffect(() => {
    setInput((current) => (current.trim() === q ? current : q));
  }, [q]);

  // Debounce typing into the URL (?q=…), so searches are shareable and survive refresh.
  useEffect(() => {
    const timer = setTimeout(() => {
      const next = input.trim();
      if (next !== q) setParams(next ? { q: next } : {}, { replace: true });
    }, 300);
    return () => clearTimeout(timer);
  }, [input, q, setParams]);

  useEffect(() => {
    if (!q) {
      setResults(null);
      return undefined;
    }
    let cancelled = false;
    setResults(null);
    setSearchError('');
    api(`/users?q=${encodeURIComponent(q)}`)
      .then((res) => !cancelled && setResults(res.users))
      .catch((err) => !cancelled && setSearchError(err.message));
    return () => {
      cancelled = true;
    };
  }, [q]);

  const fetchExplore = useCallback(
    (cursor) =>
      api(withCursor('/posts/explore', cursor)).then((res) => ({ items: res.posts, nextCursor: res.nextCursor })),
    [],
  );
  const pager = usePaginated(fetchExplore, 'explore');

  return (
    <>
      <PageHeader title="Explore" />
      <div className="stack">
        <div className="search-box search-box-lg" role="search">
          <Search size={18} aria-hidden="true" />
          <input
            className="input"
            type="search"
            placeholder="Search people by name or username"
            aria-label="Search people"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        </div>

        {q ? (
          <section className="card" aria-live="polite">
            <h2 className="card-title">People matching “{q}”</h2>
            {searchError ? (
              <p className="pad muted">{searchError}</p>
            ) : results === null ? (
              <div className="center"><Spinner /></div>
            ) : results.length ? (
              <div className="user-list">
                {results.map((user) => <UserRow key={user.id} user={user} />)}
              </div>
            ) : (
              <EmptyState icon={Users} title="No one found">Try a different name or username.</EmptyState>
            )}
          </section>
        ) : (
          <>
            <div className="explore-suggestions">
              <WhoToFollow />
            </div>
            <h2 className="section-title">Recent posts</h2>
            <PostList
              pager={pager}
              empty={
                <div className="card">
                  <EmptyState icon={Compass} title="Nothing here yet">Be the first to post something!</EmptyState>
                </div>
              }
            />
          </>
        )}
      </div>
    </>
  );
}
