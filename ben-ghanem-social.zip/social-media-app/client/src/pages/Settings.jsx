import { CircleAlert, LogOut, Monitor, Moon, Sun } from 'lucide-react';
import { useState } from 'react';
import Avatar from '../components/Avatar.jsx';
import { Field, PageHeader, Spinner } from '../components/ui.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { api } from '../lib/api.js';

const FIELDS = ['name', 'bio', 'avatar', 'location', 'website'];
const pickProfile = (user) => Object.fromEntries(FIELDS.map((f) => [f, user[f] || '']));

const THEMES = [
  { value: 'system', label: 'System', icon: Monitor },
  { value: 'light', label: 'Light', icon: Sun },
  { value: 'dark', label: 'Dark', icon: Moon },
];

export default function Settings() {
  const { user, setUser, logout } = useAuth();
  const { preference, choose } = useTheme();
  const toast = useToast();
  const [form, setForm] = useState(() => pickProfile(user));
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const dirty = FIELDS.some((f) => form[f] !== (user[f] || ''));

  const fieldProps = (field) => ({
    id: field,
    className: 'input',
    value: form[field],
    onChange: (e) => {
      setForm((f) => ({ ...f, [field]: e.target.value }));
      setErrors((errs) => ({ ...errs, [field]: undefined }));
    },
    'aria-invalid': errors[field] ? true : undefined,
    'aria-describedby': errors[field] ? `${field}-error` : undefined,
  });

  async function save(e) {
    e.preventDefault();
    setSaving(true);
    setErrors({});
    setFormError('');
    try {
      const { user: updated } = await api('/users/me', { method: 'PATCH', body: form });
      setUser(updated);
      setForm(pickProfile(updated));
      toast.success('Profile saved');
    } catch (err) {
      const fieldErrors = err.fieldErrors?.() ?? {};
      if (Object.keys(fieldErrors).length) setErrors(fieldErrors);
      else setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <PageHeader title="Settings" />
      <div className="stack">
        <form className="card form-card" onSubmit={save} noValidate>
          <div>
            <h2 className="card-heading">Profile</h2>
            <p className="muted">This is how other people see you on Ben Ghanem.</p>
          </div>

          <div className="avatar-field">
            <Avatar user={{ ...user, name: form.name || user.name, avatar: form.avatar }} size={72} />
            <Field
              id="avatar"
              label="Profile photo link"
              error={errors.avatar}
              hint="Paste a link to an image (https://…). Leave empty to use your initials."
            >
              <input {...fieldProps('avatar')} type="url" inputMode="url" placeholder="https://…" />
            </Field>
          </div>

          <Field id="name" label="Name" error={errors.name}>
            <input {...fieldProps('name')} autoComplete="name" maxLength={60} />
          </Field>

          <Field id="bio" label="Bio" error={errors.bio} counter={`${form.bio.length}/160`}>
            <textarea {...fieldProps('bio')} className="input textarea" rows={3} maxLength={160} placeholder="Tell people a little about yourself" />
          </Field>

          <div className="grid-2">
            <Field id="location" label="Location" error={errors.location}>
              <input {...fieldProps('location')} maxLength={60} placeholder="City, country" />
            </Field>
            <Field id="website" label="Website" error={errors.website}>
              <input {...fieldProps('website')} type="url" inputMode="url" placeholder="https://…" />
            </Field>
          </div>

          {formError && (
            <div className="alert alert-error" role="alert">
              <CircleAlert size={18} aria-hidden="true" />
              <span>{formError}</span>
            </div>
          )}

          <div className="form-actions">
            {dirty && (
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => {
                  setForm(pickProfile(user));
                  setErrors({});
                  setFormError('');
                }}
              >
                Discard
              </button>
            )}
            <button type="submit" className="btn btn-primary" disabled={!dirty || saving}>
              {saving ? <Spinner size={16} label="Saving" /> : 'Save changes'}
            </button>
          </div>
        </form>

        <section className="card form-card">
          <div>
            <h2 className="card-heading">Appearance</h2>
            <p className="muted">Choose a theme, or follow your device setting.</p>
          </div>
          <div className="segmented" role="radiogroup" aria-label="Theme">
            {THEMES.map(({ value, label, icon: Icon }) => (
              <button
                key={value}
                type="button"
                role="radio"
                aria-checked={preference === value}
                className="segment"
                onClick={() => choose(value)}
              >
                <Icon size={16} aria-hidden="true" />
                {label}
              </button>
            ))}
          </div>
        </section>

        <section className="card form-card">
          <h2 className="card-heading">Account</h2>
          <div className="account-row">
            <div className="min-w-0">
              <div className="strong truncate">@{user.username}</div>
              <div className="muted truncate">{user.email}</div>
            </div>
            <button type="button" className="btn btn-danger" onClick={logout}>
              <LogOut size={16} aria-hidden="true" /> Log out
            </button>
          </div>
        </section>
      </div>
    </>
  );
}
