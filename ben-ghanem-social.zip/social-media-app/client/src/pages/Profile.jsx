import { CalendarDays, CircleAlert, Link as LinkIcon, MapPin, MessageCircle, PenSquare, UserX, Users } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Avatar, { coverFor } from '../components/Avatar.jsx';
import FollowButton, { useFollowChanges } from '../components/FollowButton.jsx';
import PostList from '../components/PostList.jsx';
import RichText from '../components/RichText.jsx';
import { EmptyState, PageHeader, Spinner } from '../components/ui.jsx';
import UserRow from '../components/UserRow.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { usePaginated } from '../hooks/usePaginated.js';
import { api, withCursor } from '../lib/api.js';
import { joinedDate } from '../lib/time.js';

const TABS = [
  { id: 'posts', label: 'Posts' },
  { id: 'followers', label: 'Followers' },
  { id: 'following', label: 'Following' },
];

export default function Profile() {
  const { username } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState(null);
  const [tab, setTab] = useState('posts');
  const [openingChat, setOpeningChat] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setProfile(null);
    setError(null);
    setTab('posts');
    api(`/users/${encodeURIComponent(username)}`)
      .then((res) => !cancelled && setProfile(res.user))
      .catch((err) => !cancelled && setError(err));
    return () => {
      cancelled = true;
    };
  }, [username]);

  // Following this person from anywhere (e.g. the sidebar) updates the header counts.
  useFollowChanges(
    useCallback((change) => {
      setProfile((p) =>
        p && p.id === change.userId
          ? { ...p, isFollowing: change.following, followersCount: change.followersCount }
          : p,
      );
    }, []),
  );

  async function openChat() {
    setOpeningChat(true);
    try {
      const { conversation } = await api('/conversations', { method: 'POST', body: { userId: profile.id } });
      navigate(`/messages/${conversation.id}`);
    } catch (err) {
      toast.error(err.message);
      setOpeningChat(false);
    }
  }

  if (error) {
    const missing = error.status === 404;
    return (
      <>
        <PageHeader title="Profile" back />
        <div className="card">
          <EmptyState
            icon={missing ? UserX : CircleAlert}
            title={missing ? 'This account doesn’t exist' : 'Couldn’t load this profile'}
            action={<Link to="/explore" className="btn btn-secondary">Find people</Link>}
          >
            {missing ? `There’s no one called @${username}.` : error.message}
          </EmptyState>
        </div>
      </>
    );
  }

  if (!profile) {
    return (
      <>
        <PageHeader title="Profile" back />
        <div className="card profile" aria-busy="true">
          <div className="profile-cover skeleton" />
          <div className="center"><Spinner /></div>
        </div>
      </>
    );
  }

  const website = profile.website.replace(/^https?:\/\//, '').replace(/\/$/, '');

  return (
    <>
      <PageHeader title={profile.name} subtitle={`@${profile.username}`} back />
      <div className="stack">
        <section className="card profile">
          <div className="profile-cover" style={{ background: coverFor(profile.username) }} />
          <div className="profile-body">
            <div className="profile-top">
              <Avatar user={profile} size={108} className="profile-avatar" />
              <div className="profile-actions">
                {profile.isMe ? (
                  <Link to="/settings" className="btn btn-secondary">
                    <PenSquare size={16} aria-hidden="true" /> Edit profile
                  </Link>
                ) : (
                  <>
                    <button
                      type="button"
                      className="btn btn-secondary btn-icon-only-mobile"
                      onClick={openChat}
                      disabled={openingChat}
                      aria-label={`Message ${profile.name}`}
                    >
                      <MessageCircle size={17} aria-hidden="true" />
                      <span>Message</span>
                    </button>
                    <FollowButton key={profile.id} user={profile} />
                  </>
                )}
              </div>
            </div>

            <h2 className="profile-name">{profile.name}</h2>
            <div className="muted">@{profile.username}</div>
            {profile.bio && (
              <p className="profile-bio">
                <RichText text={profile.bio} />
              </p>
            )}

            <div className="profile-meta">
              {profile.location && (
                <span><MapPin size={15} aria-hidden="true" />{profile.location}</span>
              )}
              {website && (
                <a href={profile.website} target="_blank" rel="noopener noreferrer nofollow">
                  <LinkIcon size={15} aria-hidden="true" />{website}
                </a>
              )}
              <span><CalendarDays size={15} aria-hidden="true" />Joined {joinedDate(profile.createdAt)}</span>
            </div>

            <div className="profile-stats">
              <button type="button" onClick={() => setTab('following')}>
                <strong>{profile.followingCount}</strong> Following
              </button>
              <button type="button" onClick={() => setTab('followers')}>
                <strong>{profile.followersCount}</strong> {profile.followersCount === 1 ? 'Follower' : 'Followers'}
              </button>
            </div>
          </div>

          <div className="tabs" role="tablist" aria-label="Profile sections">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                id={`tab-${t.id}`}
                aria-selected={tab === t.id}
                aria-controls="profile-panel"
                className="tab"
                onClick={() => setTab(t.id)}
              >
                {t.label}
              </button>
            ))}
          </div>
        </section>

        <div id="profile-panel" role="tabpanel" aria-labelledby={`tab-${tab}`}>
          {tab === 'posts' ? (
            <ProfilePosts key={profile.id} profile={profile} />
          ) : (
            <Connections
              key={`${profile.username}-${tab}-${profile.followersCount}`}
              username={profile.username}
              type={tab}
            />
          )}
        </div>
      </div>
    </>
  );
}

function ProfilePosts({ profile }) {
  const fetchPosts = useCallback(
    (cursor) =>
      api(withCursor(`/posts/user/${profile.id}`, cursor)).then((res) => ({
        items: res.posts,
        nextCursor: res.nextCursor,
      })),
    [profile.id],
  );
  const pager = usePaginated(fetchPosts, profile.id);

  return (
    <PostList
      pager={pager}
      empty={
        <div className="card">
          <EmptyState
            icon={PenSquare}
            title="No posts yet"
            action={profile.isMe && <Link to="/" className="btn btn-primary">Write your first post</Link>}
          >
            {profile.isMe ? 'Share something with your followers.' : `When @${profile.username} posts, it’ll show up here.`}
          </EmptyState>
        </div>
      }
    />
  );
}

function Connections({ username, type }) {
  const [users, setUsers] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    api(`/users/${encodeURIComponent(username)}/${type}`)
      .then((res) => !cancelled && setUsers(res.users))
      .catch((err) => !cancelled && setError(err.message));
    return () => {
      cancelled = true;
    };
  }, [username, type]);

  if (error) return <div className="card"><p className="pad muted">{error}</p></div>;
  if (!users) return <div className="card center"><Spinner /></div>;
  if (!users.length) {
    return (
      <div className="card">
        <EmptyState icon={Users} title={type === 'followers' ? 'No followers yet' : 'Not following anyone yet'} />
      </div>
    );
  }
  return (
    <div className="card user-list">
      {users.map((user) => <UserRow key={user.id} user={user} />)}
    </div>
  );
}
