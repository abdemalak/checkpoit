import { ArrowLeft, CircleAlert, MessageCircle, Search, SendHorizontal } from 'lucide-react';
import { Fragment, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Avatar from '../components/Avatar.jsx';
import { autosize, EmptyState, Spinner } from '../components/ui.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { useSocket, useSocketEvent } from '../context/SocketContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { api, withCursor } from '../lib/api.js';
import { clockTime, dayLabel, fullDate, timeAgo } from '../lib/time.js';

export default function Messages() {
  const { conversationId } = useParams();
  const [conversations, setConversations] = useState(null);
  const [listError, setListError] = useState('');

  const loadConversations = useCallback(async () => {
    try {
      const res = await api('/conversations');
      setConversations(res.conversations);
      setListError('');
    } catch (err) {
      setListError(err.message);
    }
  }, []);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  // Any new message (sent or received) can change ordering and previews.
  useSocketEvent('message:new', loadConversations);

  const markReadLocally = useCallback((id) => {
    setConversations((list) => list?.map((c) => (c.id === id ? { ...c, unreadCount: 0 } : c)));
  }, []);

  return (
    <div className={`card messages ${conversationId ? 'has-thread' : ''}`}>
      <ConversationList conversations={conversations} error={listError} activeId={conversationId} />
      <section className="thread" aria-label="Conversation">
        {conversationId ? (
          <Thread
            key={conversationId}
            conversationId={conversationId}
            onActivity={loadConversations}
            onRead={markReadLocally}
          />
        ) : (
          <div className="thread-empty">
            <EmptyState icon={MessageCircle} title="Your messages">
              Pick a conversation, or search for someone to start a new one.
            </EmptyState>
          </div>
        )}
      </section>
    </div>
  );
}

function ConversationList({ conversations, error, activeId }) {
  const navigate = useNavigate();
  const toast = useToast();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);

  useEffect(() => {
    const q = query.trim();
    if (!q) {
      setResults(null);
      return undefined;
    }
    let cancelled = false;
    const timer = setTimeout(() => {
      api(`/users?q=${encodeURIComponent(q)}`)
        .then((res) => !cancelled && setResults(res.users.filter((u) => !u.isMe)))
        .catch(() => !cancelled && setResults([]));
    }, 250);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  async function startChat(user) {
    try {
      const { conversation } = await api('/conversations', { method: 'POST', body: { userId: user.id } });
      setQuery('');
      navigate(`/messages/${conversation.id}`);
    } catch (err) {
      toast.error(err.message);
    }
  }

  let content;
  if (query.trim()) {
    content =
      results === null ? (
        <div className="center"><Spinner /></div>
      ) : results.length ? (
        results.map((user) => (
          <button key={user.id} type="button" className="convo-item" onClick={() => startChat(user)}>
            <Avatar user={user} size={44} />
            <span className="convo-item-text">
              <span className="strong truncate">{user.name}</span>
              <span className="muted small truncate">@{user.username}</span>
            </span>
          </button>
        ))
      ) : (
        <p className="pad muted">No people match “{query.trim()}”.</p>
      );
  } else if (conversations === null) {
    content = error ? <p className="pad muted">{error}</p> : <div className="center"><Spinner /></div>;
  } else if (!conversations.length) {
    content = (
      <EmptyState icon={MessageCircle} title="No conversations yet">
        Search for someone above to say hi.
      </EmptyState>
    );
  } else {
    content = conversations.map((convo) => (
      <ConversationItem key={convo.id} convo={convo} active={convo.id === activeId} />
    ));
  }

  return (
    <aside className="convo-list" aria-label="Conversations">
      <div className="convo-list-head">
        <h1 className="convo-title">Messages</h1>
        <div className="search-box" role="search">
          <Search size={17} aria-hidden="true" />
          <input
            className="input"
            type="search"
            placeholder="Start a new chat…"
            aria-label="Search people to message"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>
      <div className="convo-items">{content}</div>
    </aside>
  );
}

function ConversationItem({ convo, active }) {
  const { user: me } = useAuth();
  const unread = convo.unreadCount > 0 && !active;
  const last = convo.lastMessage;
  const preview = last ? `${last.sender === me.id ? 'You: ' : ''}${last.text}` : 'Say hello 👋';

  return (
    <Link
      to={`/messages/${convo.id}`}
      className={`convo-item ${active ? 'active' : ''} ${unread ? 'unread' : ''}`}
      aria-current={active ? 'page' : undefined}
    >
      <Avatar user={convo.otherUser} size={48} />
      <span className="convo-item-text">
        <span className="convo-item-top">
          <span className="strong truncate">{convo.otherUser.name}</span>
          {last && (
            <time className="muted small" dateTime={last.createdAt}>{timeAgo(last.createdAt)}</time>
          )}
        </span>
        <span className="convo-item-bottom">
          <span className="convo-item-preview truncate">{preview}</span>
          {unread && <span className="unread-dot" aria-label={`${convo.unreadCount} unread`} />}
        </span>
      </span>
    </Link>
  );
}

function Thread({ conversationId, onActivity, onRead }) {
  const { user: me } = useAuth();
  const socket = useSocket();
  const toast = useToast();
  const [convo, setConvo] = useState(null);
  const [messages, setMessages] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [status, setStatus] = useState('loading');
  const [loadError, setLoadError] = useState(null);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [otherTyping, setOtherTyping] = useState(false);

  const bodyRef = useRef(null);
  const inputRef = useRef(null);
  const typingTimer = useRef(null);
  const lastTypingSent = useRef(0);
  // What to do with the scroll position after the next render of `messages`.
  const scrollIntent = useRef('bottom');

  const markRead = useCallback(() => {
    api(`/conversations/${conversationId}/read`, { method: 'POST' })
      .then(() => {
        onRead(conversationId);
        window.dispatchEvent(new Event('benghanem:messages-read'));
      })
      .catch(() => {});
  }, [conversationId, onRead]);

  useEffect(() => {
    let cancelled = false;
    Promise.all([api(`/conversations/${conversationId}`), api(`/conversations/${conversationId}/messages`)])
      .then(([convoRes, messagesRes]) => {
        if (cancelled) return;
        scrollIntent.current = 'bottom';
        setConvo(convoRes.conversation);
        setMessages(messagesRes.messages);
        setCursor(messagesRes.nextCursor);
        setStatus('ready');
        markRead();
      })
      .catch((err) => {
        if (cancelled) return;
        setLoadError(err);
        setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [conversationId, markRead]);

  useLayoutEffect(() => {
    const el = bodyRef.current;
    const intent = scrollIntent.current;
    if (!el || !intent) return;
    if (intent === 'bottom') el.scrollTop = el.scrollHeight;
    else el.scrollTop = el.scrollHeight - intent.height + intent.top; // keep place after loading older
    scrollIntent.current = null;
  }, [messages, status]);

  useEffect(() => {
    if (status === 'ready') inputRef.current?.focus();
  }, [status]);

  useSocketEvent('message:new', (message) => {
    if (message.conversationId !== conversationId) return;
    const el = bodyRef.current;
    const nearBottom = el && el.scrollHeight - el.scrollTop - el.clientHeight < 150;
    if (nearBottom || message.sender === me.id) scrollIntent.current = 'bottom';
    setMessages((list) => (list.some((m) => m.id === message.id) ? list : [...list, message]));
    if (message.sender !== me.id) {
      setOtherTyping(false);
      if (document.visibilityState === 'visible') markRead();
    }
  });

  useSocketEvent('messages:read', ({ conversationId: id, readerId }) => {
    if (id !== conversationId) return;
    setMessages((list) =>
      list.map((m) => (m.readBy.includes(readerId) ? m : { ...m, readBy: [...m.readBy, readerId] })),
    );
  });

  useSocketEvent('typing', ({ conversationId: id }) => {
    if (id !== conversationId) return;
    setOtherTyping(true);
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => setOtherTyping(false), 3000);
  });

  useEffect(() => () => clearTimeout(typingTimer.current), []);

  // Coming back to the tab marks new messages as read.
  useEffect(() => {
    const onVisible = () => document.visibilityState === 'visible' && markRead();
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [markRead]);

  async function loadOlder() {
    if (!cursor || loadingOlder) return;
    setLoadingOlder(true);
    try {
      const res = await api(withCursor(`/conversations/${conversationId}/messages`, cursor));
      const el = bodyRef.current;
      scrollIntent.current = { height: el.scrollHeight, top: el.scrollTop };
      setMessages((list) => [...res.messages, ...list]);
      setCursor(res.nextCursor);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoadingOlder(false);
    }
  }

  function onType(value) {
    setText(value);
    const now = Date.now();
    if (socket && value.trim() && now - lastTypingSent.current > 2000) {
      lastTypingSent.current = now;
      socket.emit('typing', { conversationId });
    }
  }

  async function send(e) {
    e?.preventDefault();
    const value = text.trim();
    if (!value || sending) return;
    setSending(true);
    try {
      const { message } = await api(`/conversations/${conversationId}/messages`, {
        method: 'POST',
        body: { text: value },
      });
      scrollIntent.current = 'bottom';
      setMessages((list) => (list.some((m) => m.id === message.id) ? list : [...list, message]));
      setText('');
      lastTypingSent.current = 0;
      if (inputRef.current) inputRef.current.style.height = '';
      onActivity();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  }

  if (status === 'error') {
    const missing = loadError?.status === 404;
    return (
      <div className="thread-empty">
        <EmptyState
          icon={CircleAlert}
          title={missing ? 'Conversation not found' : 'Couldn’t load this conversation'}
          action={<Link to="/messages" className="btn btn-secondary">Back to messages</Link>}
        >
          {missing ? 'It may have been removed, or the link is wrong.' : loadError?.message}
        </EmptyState>
      </div>
    );
  }

  const other = convo?.otherUser;
  const lastMessage = messages.at(-1);
  const seen = lastMessage && other && lastMessage.sender === me.id && lastMessage.readBy.includes(other.id);

  return (
    <>
      <header className="thread-head">
        <Link to="/messages" className="icon-btn thread-back" aria-label="Back to conversations">
          <ArrowLeft size={20} />
        </Link>
        {other ? (
          <Link to={`/u/${other.username}`} className="thread-user">
            <Avatar user={other} size={40} />
            <span className="min-w-0">
              <span className="strong truncate d-block">{other.name}</span>
              <span className="muted small truncate d-block">@{other.username}</span>
            </span>
          </Link>
        ) : (
          <div className="skeleton" style={{ width: 180, height: 36 }} />
        )}
      </header>

      <div className="thread-body" ref={bodyRef}>
        {status === 'loading' ? (
          <div className="center"><Spinner /></div>
        ) : (
          <div role="log" aria-live="polite" aria-label={`Messages with ${other.name}`} className="thread-log">
            {cursor ? (
              <button type="button" className="btn btn-ghost btn-sm load-older" onClick={loadOlder} disabled={loadingOlder}>
                {loadingOlder ? <Spinner size={16} /> : 'Load earlier messages'}
              </button>
            ) : (
              <div className="thread-start">
                <Avatar user={other} size={64} />
                <div className="strong">{other.name}</div>
                <div className="muted small">This is the start of your conversation with @{other.username}.</div>
              </div>
            )}

            {messages.map((message, i) => {
              const prev = messages[i - 1];
              const newDay = !prev || new Date(prev.createdAt).toDateString() !== new Date(message.createdAt).toDateString();
              const grouped =
                !newDay && prev.sender === message.sender &&
                new Date(message.createdAt) - new Date(prev.createdAt) < 5 * 60 * 1000;
              const mine = message.sender === me.id;
              return (
                <Fragment key={message.id}>
                  {newDay && <div className="day-sep">{dayLabel(message.createdAt)}</div>}
                  <div className={`bubble-row ${mine ? 'mine' : 'theirs'} ${grouped ? 'grouped' : ''}`}>
                    <div className={`bubble ${mine ? 'mine' : 'theirs'}`} title={fullDate(message.createdAt)}>
                      {message.text}
                      <time className="bubble-time" dateTime={message.createdAt}>{clockTime(message.createdAt)}</time>
                    </div>
                  </div>
                </Fragment>
              );
            })}
            {seen && <div className="seen">Seen</div>}
          </div>
        )}
      </div>

      <div className="typing-indicator" aria-live="polite">
        {otherTyping && other && (
          <>
            <span className="dots" aria-hidden="true"><i /><i /><i /></span>
            {other.name.split(' ')[0]} is typing…
          </>
        )}
      </div>

      <form className="thread-composer" onSubmit={send}>
        <label htmlFor="message-input" className="sr-only">Message</label>
        <textarea
          id="message-input"
          ref={inputRef}
          className="input"
          rows={1}
          placeholder="Write a message…"
          value={text}
          maxLength={2000}
          disabled={status !== 'ready'}
          onChange={(e) => {
            onType(e.target.value);
            autosize(e.target);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              send();
            }
          }}
        />
        <button type="submit" className="btn btn-primary btn-round" disabled={!text.trim() || sending} aria-label="Send message">
          <SendHorizontal size={18} />
        </button>
      </form>
    </>
  );
}
