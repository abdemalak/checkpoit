import { CircleAlert, Eye, EyeOff, MessageCircle, Sparkles, Users } from 'lucide-react';
import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { api } from '../lib/api.js';
import { Field, Logo, Spinner } from '../components/ui.jsx';

function AuthLayout({ children }) {
  return (
    <div className="auth">
      <section className="auth-hero">
        <div className="auth-hero-brand">
          <Logo size={36} />
          <span>Ben Ghanem</span>
        </div>
        <div className="auth-hero-copy">
          <h1>Your people, all in one place.</h1>
          <p>Share what you’re up to, follow the people you care about and chat in real time.</p>
          <ul className="auth-features">
            <li>
              <span className="auth-feature-icon"><Sparkles size={18} /></span>
              A feed made of the people you follow
            </li>
            <li>
              <span className="auth-feature-icon"><MessageCircle size={18} /></span>
              Private messages that arrive instantly
            </li>
            <li>
              <span className="auth-feature-icon"><Users size={18} /></span>
              Profiles, followers, likes and comments
            </li>
          </ul>
        </div>
        <p className="auth-hero-foot">Built with React, Node.js, Express, MongoDB and Socket.io</p>
        <div className="hero-ring ring-1" aria-hidden="true" />
        <div className="hero-ring ring-2" aria-hidden="true" />
        <div className="hero-ring ring-3" aria-hidden="true" />
      </section>
      <main className="auth-main">
        <div className="auth-card">
          <div className="auth-mobile-brand">
            <Logo size={32} />
            <span>Ben Ghanem</span>
          </div>
          {children}
        </div>
      </main>
    </div>
  );
}

function PasswordInput({ id, value, onChange, autoComplete, invalid, describedBy }) {
  const [visible, setVisible] = useState(false);
  return (
    <div className="input-with-action">
      <input
        id={id}
        className="input"
        type={visible ? 'text' : 'password'}
        autoComplete={autoComplete}
        value={value}
        onChange={onChange}
        aria-invalid={invalid || undefined}
        aria-describedby={describedBy}
      />
      <button
        type="button"
        className="icon-btn icon-btn-sm"
        onClick={() => setVisible((v) => !v)}
        aria-label={visible ? 'Hide password' : 'Show password'}
      >
        {visible ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  );
}

export function Login() {
  const { authenticate } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await api('/auth/login', { method: 'POST', body: { identifier, password } });
      authenticate(data);
      const from = location.state?.from;
      navigate(from ? `${from.pathname}${from.search || ''}` : '/', { replace: true });
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <AuthLayout>
      <div>
        <h2>Welcome back</h2>
        <p className="muted">Log in to catch up with your people.</p>
      </div>
      <form className="stack" onSubmit={submit} noValidate>
        {error && (
          <div className="alert alert-error" role="alert">
            <CircleAlert size={18} aria-hidden="true" />
            <span>{error}</span>
          </div>
        )}
        <Field id="identifier" label="Email or username">
          <input
            id="identifier"
            className="input"
            autoComplete="username"
            autoCapitalize="none"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            autoFocus
          />
        </Field>
        <Field id="password" label="Password">
          <PasswordInput
            id="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={loading || !identifier || !password}>
          {loading ? <Spinner size={18} label="Logging in" /> : 'Log in'}
        </button>
      </form>

      {import.meta.env.DEV && (
        <div className="demo-hint">
          <span>
            Local demo account: <code>demo</code> / <code>password123</code>
          </span>
          <button
            type="button"
            className="link-btn"
            onClick={() => {
              setIdentifier('demo');
              setPassword('password123');
            }}
          >
            Fill in
          </button>
        </div>
      )}

      <p className="auth-switch">
        New to Ben Ghanem? <Link to="/register">Create an account</Link>
      </p>
    </AuthLayout>
  );
}

export function Register() {
  const { authenticate } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', username: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const update = (field) => (e) => {
    const value = field === 'username' ? e.target.value.toLowerCase().replace(/\s/g, '') : e.target.value;
    setForm((f) => ({ ...f, [field]: value }));
    setErrors((errs) => ({ ...errs, [field]: undefined }));
  };

  async function submit(e) {
    e.preventDefault();
    setErrors({});
    setFormError('');
    setLoading(true);
    try {
      const data = await api('/auth/register', { method: 'POST', body: form });
      authenticate(data);
      navigate('/', { replace: true });
    } catch (err) {
      const fieldErrors = err.fieldErrors?.() ?? {};
      if (Object.keys(fieldErrors).length) setErrors(fieldErrors);
      else setFormError(err.message);
      setLoading(false);
    }
  }

  const inputProps = (field) => ({
    id: field,
    className: 'input',
    value: form[field],
    onChange: update(field),
    'aria-invalid': errors[field] ? true : undefined,
    'aria-describedby': errors[field] ? `${field}-error` : `${field}-hint`,
  });

  return (
    <AuthLayout>
      <div>
        <h2>Create your account</h2>
        <p className="muted">It takes less than a minute.</p>
      </div>
      <form className="stack" onSubmit={submit} noValidate>
        {formError && (
          <div className="alert alert-error" role="alert">
            <CircleAlert size={18} aria-hidden="true" />
            <span>{formError}</span>
          </div>
        )}
        <Field id="name" label="Name" error={errors.name}>
          <input {...inputProps('name')} autoComplete="name" maxLength={60} autoFocus />
        </Field>
        <Field id="username" label="Username" error={errors.username} hint="3–20 characters: letters, numbers and _">
          <div className="input-prefix">
            <span aria-hidden="true">@</span>
            <input {...inputProps('username')} autoComplete="username" autoCapitalize="none" maxLength={20} />
          </div>
        </Field>
        <Field id="email" label="Email" error={errors.email}>
          <input {...inputProps('email')} type="email" autoComplete="email" />
        </Field>
        <Field id="password" label="Password" error={errors.password} hint="At least 6 characters">
          <PasswordInput
            id="password"
            autoComplete="new-password"
            value={form.password}
            onChange={update('password')}
            invalid={Boolean(errors.password)}
            describedBy={errors.password ? 'password-error' : 'password-hint'}
          />
        </Field>
        <button
          type="submit"
          className="btn btn-primary btn-lg btn-block"
          disabled={loading || !form.name || !form.username || !form.email || !form.password}
        >
          {loading ? <Spinner size={18} label="Creating account" /> : 'Create account'}
        </button>
      </form>
      <p className="auth-switch">
        Already have an account? <Link to="/login">Log in</Link>
      </p>
    </AuthLayout>
  );
}
