import { CircleOff } from 'lucide-react';
import { BrowserRouter, Link, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import { EmptyState, Logo, PageHeader } from './components/ui.jsx';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { SocketProvider } from './context/SocketContext.jsx';
import { ThemeProvider } from './context/ThemeContext.jsx';
import { ToastProvider } from './context/ToastContext.jsx';
import { Login, Register } from './pages/AuthPages.jsx';
import Explore from './pages/Explore.jsx';
import Feed from './pages/Feed.jsx';
import Messages from './pages/Messages.jsx';
import Profile from './pages/Profile.jsx';
import Settings from './pages/Settings.jsx';

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <SocketProvider>
            <BrowserRouter>
              <AppRoutes />
            </BrowserRouter>
          </SocketProvider>
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}

function AppRoutes() {
  const { status, user } = useAuth();

  if (status === 'loading') {
    return (
      <div className="full-screen" aria-busy="true">
        <div className="pulse"><Logo size={56} /></div>
      </div>
    );
  }
  if (status === 'error') {
    return (
      <div className="full-screen">
        <EmptyState
          icon={CircleOff}
          title="Can’t reach Ben Ghanem"
          action={<button type="button" className="btn btn-primary" onClick={() => window.location.reload()}>Try again</button>}
        >
          The server isn’t responding. Check your connection and try again.
        </EmptyState>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/" replace /> : <Register />} />
      <Route element={<RequireAuth />}>
        <Route index element={<Feed />} />
        <Route path="explore" element={<Explore />} />
        <Route path="messages/:conversationId?" element={<Messages />} />
        <Route path="u/:username" element={<Profile />} />
        <Route path="settings" element={<Settings />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

function RequireAuth() {
  const { user } = useAuth();
  const location = useLocation();
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  return <Layout />;
}

function NotFound() {
  return (
    <>
      <PageHeader title="Not found" back />
      <div className="card">
        <EmptyState
          icon={CircleOff}
          title="This page doesn’t exist"
          action={<Link to="/" className="btn btn-primary">Go home</Link>}
        >
          The link may be broken, or the page may have been removed.
        </EmptyState>
      </div>
    </>
  );
}
