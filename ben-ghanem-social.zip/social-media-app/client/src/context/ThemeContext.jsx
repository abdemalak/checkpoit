import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { storage } from '../lib/storage.js';

const THEME_KEY = 'benghanem-theme';
const ThemeContext = createContext(null);
const darkQuery = () => window.matchMedia('(prefers-color-scheme: dark)');

export function ThemeProvider({ children }) {
  const [preference, setPreference] = useState(() => storage.get(THEME_KEY) || 'system');
  const [systemDark, setSystemDark] = useState(() => darkQuery().matches);

  useEffect(() => {
    const query = darkQuery();
    const onChange = (e) => setSystemDark(e.matches);
    query.addEventListener('change', onChange);
    return () => query.removeEventListener('change', onChange);
  }, []);

  const resolved = preference === 'system' ? (systemDark ? 'dark' : 'light') : preference;

  useEffect(() => {
    document.documentElement.dataset.theme = resolved;
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute('content', resolved === 'dark' ? '#0c0e14' : '#f4f5fa');
  }, [resolved]);

  const choose = useCallback((value) => {
    storage.set(THEME_KEY, value);
    setPreference(value);
  }, []);

  const toggle = useCallback(() => choose(resolved === 'dark' ? 'light' : 'dark'), [choose, resolved]);

  const value = useMemo(() => ({ preference, resolved, choose, toggle }), [preference, resolved, choose, toggle]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);
