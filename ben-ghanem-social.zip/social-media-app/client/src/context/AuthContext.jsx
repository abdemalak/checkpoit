import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, TOKEN_KEY } from '../lib/api.js';
import { storage } from '../lib/storage.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => storage.get(TOKEN_KEY));
  const [user, setUser] = useState(null);
  // loading: checking a saved session · ready · error: server unreachable
  const [status, setStatus] = useState(() => (storage.get(TOKEN_KEY) ? 'loading' : 'ready'));

  const logout = useCallback(() => {
    storage.remove(TOKEN_KEY);
    setToken(null);
    setUser(null);
    setStatus('ready');
  }, []);

  const authenticate = useCallback(({ token: newToken, user: newUser }) => {
    storage.set(TOKEN_KEY, newToken);
    setToken(newToken);
    setUser(newUser);
    setStatus('ready');
  }, []);

  // Restore the session saved from a previous visit.
  useEffect(() => {
    if (!storage.get(TOKEN_KEY)) return undefined;
    let cancelled = false;
    api('/auth/me')
      .then(({ user: me }) => {
        if (cancelled) return;
        setUser(me);
        setStatus('ready');
      })
      .catch((err) => {
        if (cancelled) return;
        if (err.status === 401) logout();
        else setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [logout]);

  useEffect(() => {
    window.addEventListener('benghanem:unauthorized', logout);
    return () => window.removeEventListener('benghanem:unauthorized', logout);
  }, [logout]);

  const value = useMemo(
    () => ({ token, user, status, authenticate, logout, setUser }),
    [token, user, status, authenticate, logout],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
