import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

const API = process.env.API_PROXY_TARGET || 'http://localhost:5050';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // In development the React app calls /api and /socket.io on its own origin;
    // Vite forwards those requests to the Express server.
    proxy: {
      '/api': API,
      '/socket.io': { target: API, ws: true },
    },
  },
});
