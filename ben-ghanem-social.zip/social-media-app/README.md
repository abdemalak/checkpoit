# Ben Ghanem — Social Media Application

A full-stack social media app: post updates, follow people, like and comment, and chat in real time.

**Stack:** React 19 + Vite · Node.js + Express 5 · MongoDB + Mongoose · Socket.io · JWT auth

| Phase | What was built |
| --- | --- |
| **1. Front-end (ReactJS)** | Responsive UI (desktop sidebar → tablet icon rail → phone tab bar), light/dark theme, feed, explore & people search, profiles with followers/following, settings, real-time messaging UI with typing indicator and read receipts |
| **2. Back-end (Node.js + Express)** | REST API for authentication, profile management, following, posts, likes, comments and messaging; Socket.io for live delivery; validation, rate limiting, security headers; 16 automated API tests |
| **3. Deployment** | One-service production build (Express serves the React app), Render blueprint, MongoDB Atlas setup, health check and a production test checklist |

---

## Getting started

**Requirements:** Node.js 20.19+ (22 LTS recommended) and npm.

```bash
npm install
npm run dev
```

Open **http://localhost:5173**.

- You don't need to install MongoDB. If `MONGO_URI` isn't set, the API starts a local MongoDB automatically and stores its data in `~/.ben-ghanem-dev/db`.
- On first run it adds demo data. Log in as **`demo`** with password **`password123`**; there are a few other demo users to follow and message. All demo accounts use that password.
- The first `npm install` downloads a MongoDB binary for this local database, which can take a while on a slow connection.

To use your own database instead, copy `server/.env.example` to `server/.env` and set `MONGO_URI`.

### Scripts (run from the project root)

| Command | What it does |
| --- | --- |
| `npm run dev` | API on :5050 + React on :5173 with hot reload |
| `npm test` | Runs the API test suite (in-memory MongoDB) |
| `npm run build` | Builds the React app into `client/dist` |
| `npm start` | Production server: API + Socket.io + built React app |
| `npm run seed` | Adds demo data if the database is empty (`npm run seed -- --reset` wipes it first) |

---

## Project structure

```
social-media-app/
├── client/                 React front end (Vite)
│   └── src/
│       ├── components/     Layout, PostCard, PostComposer, Avatar, FollowButton…
│       ├── context/        Auth, Socket.io, theme and toast providers
│       ├── hooks/          usePaginated (cursor pagination + infinite scroll)
│       ├── lib/            API client, time formatting, safe localStorage
│       ├── pages/          Login/Register, Feed, Explore, Profile, Messages, Settings
│       └── styles.css      Design tokens, light/dark themes, responsive layout
├── server/                 Express API
│   ├── src/
│   │   ├── models/         User, Post (with comments), Conversation, Message
│   │   ├── routes/         auth, users, posts, conversations
│   │   ├── middleware/     JWT auth, zod validation, error handler
│   │   ├── utils/          pagination, serializers, tokens, HTTP errors
│   │   ├── socket.js       Real-time events
│   │   ├── seed.js         Demo data
│   │   └── app.js / index.js
│   └── tests/api.test.js   Integration tests (Vitest + Supertest)
└── render.yaml             One-click deployment on Render
```

---

## API reference

All endpoints are under `/api`. Everything except register/login/health needs an `Authorization: Bearer <token>` header. Errors look like `{ "error": "message", "details": [{ "field", "message" }] }`.

**Authentication**

| Method | Path | Description |
| --- | --- | --- |
| POST | `/auth/register` | `{ name, username, email, password }` → `{ token, user }` |
| POST | `/auth/login` | `{ identifier (email or username), password }` → `{ token, user }` |
| GET | `/auth/me` | The signed-in user |

**Profiles & following**

| Method | Path | Description |
| --- | --- | --- |
| GET | `/users?q=` | Search people by name or username |
| GET | `/users/suggestions` | People you don't follow yet |
| PATCH | `/users/me` | Update `name`, `bio`, `avatar`, `location`, `website` |
| GET | `/users/:username` | Public profile (counts, `isFollowing`) |
| GET | `/users/:username/followers` · `/following` | Connections |
| POST / DELETE | `/users/:id/follow` | Follow / unfollow |

**Posts**

| Method | Path | Description |
| --- | --- | --- |
| GET | `/posts/feed?cursor=` | You + people you follow (paginated) |
| GET | `/posts/explore?cursor=` | Everyone's recent posts |
| GET | `/posts/user/:userId?cursor=` | One user's posts |
| POST | `/posts` | `{ text, image? }` |
| GET / DELETE | `/posts/:id` | Read / delete (author only) |
| POST / DELETE | `/posts/:id/like` | Like / unlike |
| POST | `/posts/:id/comments` | `{ text }` |
| DELETE | `/posts/:id/comments/:commentId` | Comment author or post author |

**Messaging**

| Method | Path | Description |
| --- | --- | --- |
| GET | `/conversations` | Inbox with last message and unread count |
| GET | `/conversations/unread-count` | Total unread messages |
| POST | `/conversations` | `{ userId }` → opens or creates the 1-to-1 conversation |
| GET | `/conversations/:id/messages?cursor=` | Messages, oldest → newest |
| POST | `/conversations/:id/messages` | `{ text }` |
| POST | `/conversations/:id/read` | Mark as read |

**Real-time (Socket.io).** Connect with `io(url, { auth: { token } })`.

| Event | Direction | Payload |
| --- | --- | --- |
| `message:new` | server → client | the new message |
| `messages:read` | server → client | `{ conversationId, readerId }` |
| `typing` | both ways | `{ conversationId }` (relayed to the other participant) |

Pagination uses cursors: each list response includes `nextCursor`, which you pass back as `?cursor=` (it's `null` on the last page).

---

## Deployment (Phase 3)

In production, Express serves the API, Socket.io and the built React app from one URL, so there's one service to deploy and no CORS setup.

### 1. Create the database (MongoDB Atlas, free tier)

1. Sign up at [mongodb.com/atlas](https://www.mongodb.com/atlas) and create a free **M0** cluster.
2. **Database Access:** add a database user with a strong password.
3. **Network Access:** allow `0.0.0.0/0`. Render's free tier has no fixed IP, so access is protected by the user and password instead.
4. **Connect → Drivers:** copy the connection string and add a database name, for example:
   `mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/benghanem?retryWrites=true&w=majority`

### 2. Deploy the app (Render)

1. Push this project to a GitHub repository.
2. In [Render](https://render.com), choose **New → Blueprint** and select the repo. Render reads `render.yaml`.
3. When it asks for `MONGO_URI`, paste the Atlas string. `JWT_SECRET` is generated automatically.
4. Wait for the build (`npm ci --include=dev && npm run build`) and the health check (`/api/health`) to pass. Your app is live at `https://<service-name>.onrender.com`.

<details>
<summary>Manual setup without the blueprint</summary>

Create a **Web Service** from the repo with:

- Build command: `npm ci --include=dev && npm run build`
- Start command: `npm start`
- Health check path: `/api/health`
- Environment variables: `NODE_ENV=production`, `NODE_VERSION=22`, `MONGOMS_DISABLE_POSTINSTALL=1`, `MONGO_URI=…`, `JWT_SECRET=<long random string>`

The same settings work on Railway, Fly.io, Koyeb or a VPS behind nginx (make sure WebSockets are allowed).
</details>

<details>
<summary>Hosting the front end separately (Netlify / Vercel)</summary>

1. Deploy the API as above.
2. Build the client with `VITE_API_URL=https://<your-api>.onrender.com npm run build -w client` and host `client/dist`. Add an SPA rewrite so every path serves `index.html`.
3. On the API, set `CLIENT_ORIGIN=https://<your-frontend-domain>` so CORS and Socket.io accept it.
</details>

### 3. Test the production app

Run this checklist against the live URL, using two browsers (or one normal and one private window) so you have two users:

- [ ] `https://<app>/api/health` returns `{"status":"ok"}`
- [ ] Register two new accounts; logging out and back in works; a wrong password shows an error
- [ ] Refreshing on a deep link (e.g. `/u/<username>`) loads the page instead of a 404
- [ ] Edit profile (name, bio, photo link, website); invalid links are rejected
- [ ] User A follows B → B's posts appear in A's feed; counts update; unfollow works
- [ ] Create a post (with an image link), like/unlike, comment, delete a comment and a post
- [ ] A messages B: B sees it **instantly**, along with the unread badge and "typing…"; A sees **Seen** after B opens it
- [ ] Check on a phone (or browser dev tools): bottom tab bar, no sideways scrolling, chat back button
- [ ] Switch light/dark theme; it's remembered after reload

On Render's free tier the service sleeps after 15 minutes of inactivity, so the first request afterwards takes about 30 seconds.

---

## Security notes

- Passwords are hashed with bcrypt and never returned by the API; users are serialized through explicit allow-lists.
- JWTs are signed with `JWT_SECRET`. Production refuses to start without it and without `MONGO_URI`.
- Every request body is validated with zod. Links must be `http(s)://`, which blocks `javascript:` URLs.
- Helmet sets security headers including a Content-Security-Policy. Login and registration are rate-limited.
- Only conversation participants can read or post messages. Only authors can delete their own posts and comments.

## Troubleshooting

- **Port already in use:** the dev API uses 5050 (see `server/package.json`) and Vite uses 5173. Stop whatever is using them, or change both the dev script and `client/vite.config.js`.
- **Reset the demo data:** stop the app and run `npm run seed -- --reset`, or delete `~/.ben-ghanem-dev`.
- **Windows: "spawn … ENOENT" when the local database starts:** the project is in a very deep folder and the MongoDB binary path is over 260 characters. Move the project to a shorter path (e.g. `C:\dev\ben-ghanem`), or set `MONGO_URI` to an Atlas database.
