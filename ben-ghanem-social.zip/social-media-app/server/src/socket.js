import mongoose from 'mongoose';
import { Server } from 'socket.io';
import { config } from './config.js';
import { Conversation } from './models/Conversation.js';
import { verifyToken } from './utils/token.js';

let io = null;

const userRoom = (userId) => `user:${String(userId)}`;

/**
 * Real-time layer. Each signed-in browser tab joins a private room for its
 * user; the REST API pushes new messages and read receipts into those rooms.
 */
export function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: { origin: config.clientOrigins, credentials: true },
  });

  io.use((socket, next) => {
    try {
      const payload = verifyToken(socket.handshake.auth?.token);
      socket.data.userId = String(payload.sub);
      next();
    } catch {
      next(new Error('Unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    const { userId } = socket.data;
    socket.join(userRoom(userId));

    // "typing" is relayed to the other participant, only if the sender is in the conversation.
    socket.on('typing', async ({ conversationId } = {}) => {
      try {
        if (!mongoose.isValidObjectId(conversationId)) return;
        const convo = await Conversation.findOne({ _id: conversationId, participants: userId })
          .select('participants')
          .lean();
        if (!convo) return;
        for (const participant of convo.participants) {
          if (String(participant) !== userId) {
            emitToUser(participant, 'typing', { conversationId, userId });
          }
        }
      } catch (err) {
        console.error('typing relay failed:', err.message);
      }
    });
  });

  return io;
}

/** Sends an event to every open tab of a user. Safe to call when sockets aren't running (tests). */
export function emitToUser(userId, event, payload) {
  io?.to(userRoom(userId)).emit(event, payload);
}

export function closeSocket() {
  return new Promise((resolve) => (io ? io.close(() => resolve()) : resolve()));
}
