import mongoose from 'mongoose';

const { Schema, model } = mongoose;

const conversationSchema = new Schema(
  {
    participants: [{ type: Schema.Types.ObjectId, ref: 'User', required: true }],
    // Sorted participant ids joined with ":" — guarantees one conversation per pair of users.
    key: { type: String, required: true, unique: true },
    lastMessage: {
      text: String,
      sender: { type: Schema.Types.ObjectId, ref: 'User' },
      createdAt: Date,
    },
  },
  { timestamps: true },
);

conversationSchema.index({ participants: 1, updatedAt: -1 });

export const conversationKey = (a, b) => [String(a), String(b)].sort().join(':');

export const Conversation = model('Conversation', conversationSchema);
