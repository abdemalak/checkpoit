// Demo data so the app isn't empty on first run.
// Every demo account uses the password below — for local development only.
import { pathToFileURL } from 'node:url';
import { Conversation, conversationKey } from './models/Conversation.js';
import { Message } from './models/Message.js';
import { Post } from './models/Post.js';
import { User } from './models/User.js';

export const DEMO_PASSWORD = 'password123';

const minutesAgo = (minutes) => new Date(Date.now() - minutes * 60 * 1000);

const USERS = [
  { key: 'demo', name: 'Demo User', bio: 'Just exploring Ben Ghanem 👋', location: 'Tunis' },
  { key: 'sara_dev', name: 'Sara Mansour', bio: 'Frontend developer. Coffee, CSS and long walks.', location: 'Tunis', website: 'https://example.com' },
  { key: 'youssef', name: 'Youssef Haddad', bio: 'Backend engineer · Node.js · Building things that scale', location: 'Sfax' },
  { key: 'lina_art', name: 'Lina Kacem', bio: 'Illustrator & UI designer. Colors are my love language 🎨', location: 'Sousse' },
  { key: 'omar_k', name: 'Omar Khelifi', bio: 'Learning React one component at a time.', location: 'Bizerte' },
];

const FOLLOWS = {
  demo: ['sara_dev', 'youssef', 'lina_art'],
  sara_dev: ['demo', 'youssef', 'lina_art'],
  youssef: ['sara_dev', 'demo'],
  lina_art: ['demo', 'sara_dev'],
  omar_k: ['sara_dev'],
};

const POSTS = [
  {
    author: 'sara_dev', at: 25,
    text: 'Just shipped dark mode for our dashboard 🌙 CSS custom properties turned it into a 20-line change.',
    likes: ['demo', 'youssef', 'lina_art'],
    comments: [
      { author: 'youssef', at: 20, text: 'Clean! Does it follow the OS setting too?' },
      { author: 'sara_dev', at: 18, text: 'Yes, prefers-color-scheme by default, with a manual toggle.' },
    ],
  },
  {
    author: 'omar_k', at: 95,
    text: 'Day 12 of #100DaysOfCode: I finally understand useEffect cleanup functions. Subscriptions, timers, sockets — clean them up!',
    likes: ['sara_dev'],
    comments: [{ author: 'sara_dev', at: 80, text: 'That one clicks for everyone eventually. Keep going 💪' }],
  },
  {
    author: 'youssef', at: 160,
    text: 'Hot take: most APIs don’t need GraphQL. A well-designed REST API with cursor pagination goes a long way.',
    likes: ['demo', 'omar_k'],
    comments: [{ author: 'demo', at: 150, text: 'Cursor pagination FTW 🙌' }],
  },
  {
    author: 'lina_art', at: 300,
    text: 'New illustration series dropping next week. Theme: “cities at night”. Any city requests?',
    likes: ['sara_dev', 'demo'],
    comments: [{ author: 'demo', at: 290, text: 'Tunis medina at night would be beautiful!' }],
  },
  {
    author: 'demo', at: 1440,
    text: 'Hello Ben Ghanem! This is my first post 🚀',
    likes: ['sara_dev', 'lina_art', 'youssef'],
    comments: [{ author: 'sara_dev', at: 1430, text: 'Welcome aboard!' }],
  },
  {
    author: 'youssef', at: 2000,
    text: 'Reminder: never store plain-text passwords. Hash them with bcrypt and a sensible cost factor. Always.',
    likes: ['sara_dev'],
    comments: [],
  },
];

const CONVERSATIONS = [
  {
    between: ['demo', 'sara_dev'],
    messages: [
      { from: 'sara_dev', at: 40, text: 'Hey! Welcome to Ben Ghanem 👋', read: true },
      { from: 'demo', at: 38, text: 'Thanks! Loving the dark mode already', read: true },
      { from: 'sara_dev', at: 35, text: 'Haha, that was my weekend project. Tell me if you spot any bugs!', read: false },
    ],
  },
  {
    between: ['demo', 'youssef'],
    messages: [{ from: 'youssef', at: 180, text: 'Are you coming to the Node.js meetup on Friday?', read: false }],
  },
];

export async function seedDemoData() {
  const users = {};
  for (const u of USERS) {
    users[u.key] = await User.create({
      name: u.name,
      username: u.key,
      email: `${u.key}@benghanem.dev`,
      password: DEMO_PASSWORD,
      bio: u.bio,
      location: u.location,
      website: u.website || '',
    });
  }

  for (const [follower, targets] of Object.entries(FOLLOWS)) {
    for (const target of targets) {
      await User.updateOne({ _id: users[follower]._id }, { $addToSet: { following: users[target]._id } });
      await User.updateOne({ _id: users[target]._id }, { $addToSet: { followers: users[follower]._id } });
    }
  }

  for (const p of POSTS) {
    await Post.create({
      author: users[p.author]._id,
      text: p.text,
      likes: p.likes.map((key) => users[key]._id),
      comments: p.comments.map((c) => ({ author: users[c.author]._id, text: c.text, createdAt: minutesAgo(c.at) })),
      createdAt: minutesAgo(p.at),
      updatedAt: minutesAgo(p.at),
    });
  }

  for (const c of CONVERSATIONS) {
    const [a, b] = c.between.map((key) => users[key]._id);
    const convo = await Conversation.create({ participants: [a, b], key: conversationKey(a, b) });
    for (const m of c.messages) {
      const sender = users[m.from]._id;
      const recipient = String(sender) === String(a) ? b : a;
      await Message.create({
        conversation: convo._id,
        sender,
        text: m.text,
        readBy: m.read ? [sender, recipient] : [sender],
        createdAt: minutesAgo(m.at),
      });
    }
    const last = c.messages.at(-1);
    await Conversation.updateOne(
      { _id: convo._id },
      {
        $set: {
          lastMessage: { text: last.text, sender: users[last.from]._id, createdAt: minutesAgo(last.at) },
          updatedAt: minutesAgo(last.at),
        },
      },
      { timestamps: false },
    );
  }

  return users;
}

/** Seeds only when the database has no users yet. Returns true if it seeded. */
export async function seedIfEmpty() {
  // exists() is exact; estimatedDocumentCount() can be stale after an unclean shutdown.
  if (await User.exists({})) return false;
  await seedDemoData();
  return true;
}

// `npm run seed` (add `-- --reset` to wipe existing data first)
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const { config } = await import('./config.js');
  const { connectDB, disconnectDB } = await import('./db.js');
  await connectDB(config.mongoUri);
  if (process.argv.includes('--reset')) {
    await Promise.all([User.deleteMany({}), Post.deleteMany({}), Conversation.deleteMany({}), Message.deleteMany({})]);
    console.log('Removed existing data.');
  }
  console.log((await seedIfEmpty()) ? 'Demo data added.' : 'Database already has users; nothing to do (use --reset to start over).');
  await disconnectDB();
}
