import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.js';
import { optionalHttpUrl, validate } from '../middleware/validate.js';
import { Post } from '../models/Post.js';
import { User } from '../models/User.js';
import { forbidden, notFound } from '../utils/httpError.js';
import { pageLimit, paginate } from '../utils/pagination.js';
import { serializeComment, serializePost } from '../utils/serialize.js';

const router = Router();
router.use(requireAuth);

const AUTHOR_FIELDS = 'name username avatar';
const withAuthors = (query) =>
  query.populate('author', AUTHOR_FIELDS).populate('comments.author', AUTHOR_FIELDS);

async function sendPage(req, res, filter) {
  const { items, nextCursor } = await paginate(Post, filter, {
    cursor: req.query.cursor,
    limit: pageLimit(req.query.limit, 10),
    populate: withAuthors,
  });
  res.json({ posts: items.map((post) => serializePost(post, req.userId)), nextCursor });
}

// GET /api/posts/feed — posts from the user and the people they follow
router.get('/feed', async (req, res) => {
  const me = await User.findById(req.userId).select('following');
  await sendPage(req, res, { author: { $in: [req.userId, ...me.following] } });
});

// GET /api/posts/explore — recent posts from everyone
router.get('/explore', (req, res) => sendPage(req, res, {}));

// GET /api/posts/user/:userId — one user's posts
router.get('/user/:userId', (req, res) => sendPage(req, res, { author: req.params.userId }));

const createPostSchema = z
  .object({
    text: z.string().trim().max(1000, 'Posts can be at most 1000 characters').default(''),
    image: optionalHttpUrl.default(''),
  })
  .refine((post) => post.text || post.image, {
    message: 'Write something or add an image',
    path: ['text'],
  });

// POST /api/posts — create a post
router.post('/', validate(createPostSchema), async (req, res) => {
  const post = await Post.create({ ...req.body, author: req.userId });
  await post.populate('author', AUTHOR_FIELDS);
  res.status(201).json({ post: serializePost(post, req.userId) });
});

// GET /api/posts/:id — a single post
router.get('/:id', async (req, res) => {
  const post = await withAuthors(Post.findById(req.params.id));
  if (!post) throw notFound('Post not found');
  res.json({ post: serializePost(post, req.userId) });
});

// DELETE /api/posts/:id — delete your own post
router.delete('/:id', async (req, res) => {
  const post = await Post.findById(req.params.id).select('author');
  if (!post) throw notFound('Post not found');
  if (String(post.author) !== req.userId) throw forbidden('You can only delete your own posts');
  await post.deleteOne();
  res.status(204).end();
});

const setLike = (liked) => async (req, res) => {
  const update = liked ? { $addToSet: { likes: req.userId } } : { $pull: { likes: req.userId } };
  const result = await Post.updateOne({ _id: req.params.id }, update);
  if (!result.matchedCount) throw notFound('Post not found');
  const post = await Post.findById(req.params.id).select('likes');
  res.json({ liked, likesCount: post.likes.length });
};

// POST / DELETE /api/posts/:id/like — like or unlike a post (idempotent)
router.post('/:id/like', setLike(true));
router.delete('/:id/like', setLike(false));

const commentSchema = z.object({
  text: z.string().trim().min(1, 'Comment cannot be empty').max(500, 'Comments can be at most 500 characters'),
});

// POST /api/posts/:id/comments — add a comment
router.post('/:id/comments', validate(commentSchema), async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) throw notFound('Post not found');
  post.comments.push({ author: req.userId, text: req.body.text });
  await post.save();
  await post.populate('comments.author', AUTHOR_FIELDS);
  res.status(201).json({ comment: serializeComment(post.comments.at(-1)) });
});

// DELETE /api/posts/:id/comments/:commentId — the comment's author or the post's author
router.delete('/:id/comments/:commentId', async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) throw notFound('Post not found');
  const comment = post.comments.id(req.params.commentId);
  if (!comment) throw notFound('Comment not found');
  if (String(comment.author) !== req.userId && String(post.author) !== req.userId) {
    throw forbidden('You can only delete your own comments');
  }
  comment.deleteOne();
  await post.save();
  res.status(204).end();
});

export default router;
