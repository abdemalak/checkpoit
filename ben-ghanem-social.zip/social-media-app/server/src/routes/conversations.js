import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.js';
import { objectId, validate } from '../middleware/validate.js';
import { Conversation, conversationKey } from '../models/Conversation.js';
import { Message } from '../models/Message.js';
import { User } from '../models/User.js';
import { emitToUser } from '../socket.js';
import { badRequest, notFound } from '../utils/httpError.js';
import { pageLimit, paginate } from '../utils/pagination.js';
import { serializeMessage, userSummary } from '../utils/serialize.js';

const router = Router();
router.use(requireAuth);

const PARTICIPANT_FIELDS = 'name username avatar';

const unreadFilter = (viewerId, conversationIds) => ({
  conversation: Array.isArray(conversationIds) ? { $in: conversationIds } : conversationIds,
  sender: { $ne: viewerId },
  readBy: { $ne: viewerId },
});

async function serializeConversation(convo, viewerId) {
  const other =
    convo.participants.find((p) => String(p._id) !== String(viewerId)) ?? convo.participants[0];
  const unreadCount = await Message.countDocuments(unreadFilter(viewerId, convo._id));
  return {
    id: String(convo._id),
    otherUser: userSummary(other),
    lastMessage: convo.lastMessage?.text
      ? {
          text: convo.lastMessage.text,
          sender: String(convo.lastMessage.sender),
          createdAt: convo.lastMessage.createdAt,
        }
      : null,
    updatedAt: convo.updatedAt,
    unreadCount,
  };
}

async function findOwnConversation(userId, conversationId) {
  const convo = await Conversation.findOne({ _id: conversationId, participants: userId });
  if (!convo) throw notFound('Conversation not found');
  return convo;
}

// GET /api/conversations — the inbox, most recent first
router.get('/', async (req, res) => {
  const conversations = await Conversation.find({ participants: req.userId })
    .sort({ updatedAt: -1 })
    .populate('participants', PARTICIPANT_FIELDS);
  res.json({
    conversations: await Promise.all(
      conversations.map((convo) => serializeConversation(convo, req.userId)),
    ),
  });
});

// GET /api/conversations/unread-count — total unread messages (for the nav badge)
router.get('/unread-count', async (req, res) => {
  const ids = await Conversation.find({ participants: req.userId }).distinct('_id');
  const count = await Message.countDocuments(unreadFilter(req.userId, ids));
  res.json({ count });
});

// POST /api/conversations { userId } — open (or create) a conversation with someone
router.post('/', validate(z.object({ userId: objectId })), async (req, res) => {
  const { userId } = req.body;
  if (userId === req.userId) throw badRequest("You can't message yourself");
  if (!(await User.exists({ _id: userId }))) throw notFound('User not found');

  const key = conversationKey(req.userId, userId);
  let convo = await Conversation.findOne({ key });
  let created = false;
  if (!convo) {
    try {
      convo = await Conversation.create({ participants: [req.userId, userId], key });
      created = true;
    } catch (err) {
      // Both users opened the chat at the same moment: use the one that won.
      if (err.code !== 11000) throw err;
      convo = await Conversation.findOne({ key });
    }
  }

  await convo.populate('participants', PARTICIPANT_FIELDS);
  res.status(created ? 201 : 200).json({ conversation: await serializeConversation(convo, req.userId) });
});

// GET /api/conversations/:id
router.get('/:id', async (req, res) => {
  const convo = await findOwnConversation(req.userId, req.params.id);
  await convo.populate('participants', PARTICIPANT_FIELDS);
  res.json({ conversation: await serializeConversation(convo, req.userId) });
});

// GET /api/conversations/:id/messages?cursor= — oldest-to-newest page of messages
router.get('/:id/messages', async (req, res) => {
  const convo = await findOwnConversation(req.userId, req.params.id);
  const { items, nextCursor } = await paginate(
    Message,
    { conversation: convo._id },
    { cursor: req.query.cursor, limit: pageLimit(req.query.limit, 30, 100) },
  );
  res.json({ messages: items.reverse().map(serializeMessage), nextCursor });
});

// POST /api/conversations/:id/read — mark everything in the conversation as read
router.post('/:id/read', async (req, res) => {
  const convo = await findOwnConversation(req.userId, req.params.id);
  const result = await Message.updateMany(unreadFilter(req.userId, convo._id), {
    $addToSet: { readBy: req.userId },
  });
  if (result.modifiedCount) {
    for (const participant of convo.participants) {
      if (String(participant) !== req.userId) {
        emitToUser(participant, 'messages:read', {
          conversationId: String(convo._id),
          readerId: req.userId,
        });
      }
    }
  }
  res.json({ updated: result.modifiedCount });
});

const messageSchema = z.object({
  text: z.string().trim().min(1, 'Message cannot be empty').max(2000, 'Messages can be at most 2000 characters'),
});

// POST /api/conversations/:id/messages — send a message
router.post('/:id/messages', validate(messageSchema), async (req, res) => {
  const convo = await findOwnConversation(req.userId, req.params.id);
  const message = await Message.create({
    conversation: convo._id,
    sender: req.userId,
    text: req.body.text,
    readBy: [req.userId],
  });

  convo.lastMessage = { text: message.text, sender: req.userId, createdAt: message.createdAt };
  await convo.save();

  const payload = serializeMessage(message);
  // Deliver in real time to everyone in the conversation (including the
  // sender's other open tabs; clients ignore messages they already have).
  for (const participant of convo.participants) {
    emitToUser(participant, 'message:new', payload);
  }
  res.status(201).json({ message: payload });
});

export default router;
