import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { config } from '../config.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { User, USERNAME_PATTERN } from '../models/User.js';
import { conflict, unauthorized } from '../utils/httpError.js';
import { selfProfile } from '../utils/serialize.js';
import { signToken } from '../utils/token.js';

const router = Router();

// Words that would clash with app routes if used as a username.
const RESERVED_USERNAMES = new Set([
  'admin', 'api', 'explore', 'login', 'logout', 'me', 'messages', 'register', 'settings', 'suggestions',
]);

const credentialLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  skip: () => config.isTest,
  message: { error: 'Too many attempts. Please wait a few minutes and try again.' },
});

const registerSchema = z.object({
  name: z.string().trim().min(1, 'Name is required').max(60, 'Name must be 60 characters or less'),
  username: z
    .string()
    .trim()
    .toLowerCase()
    .regex(USERNAME_PATTERN, 'Username must be 3–20 characters: letters, numbers or underscores')
    .refine((value) => !RESERVED_USERNAMES.has(value), { message: 'That username is reserved' }),
  email: z.string().trim().toLowerCase().email('Enter a valid email address'),
  password: z
    .string()
    .min(6, 'Password must be at least 6 characters')
    .max(100, 'Password must be 100 characters or less'),
});

router.post('/register', credentialLimiter, validate(registerSchema), async (req, res) => {
  const { username, email } = req.body;
  const existing = await User.findOne({ $or: [{ username }, { email }] }).select('username');
  if (existing) {
    throw conflict(
      existing.username === username
        ? 'That username is already taken'
        : 'An account with that email already exists',
    );
  }

  const user = await User.create(req.body);
  res.status(201).json({ token: signToken(user._id), user: selfProfile(user) });
});

const loginSchema = z.object({
  identifier: z.string().trim().toLowerCase().min(1, 'Enter your email or username'),
  password: z.string().min(1, 'Enter your password'),
});

router.post('/login', credentialLimiter, validate(loginSchema), async (req, res) => {
  const { identifier, password } = req.body;
  const filter = identifier.includes('@') ? { email: identifier } : { username: identifier };
  const user = await User.findOne(filter).select('+password');

  if (!user || !(await user.comparePassword(password))) {
    throw unauthorized('Incorrect email/username or password');
  }
  res.json({ token: signToken(user._id), user: selfProfile(user) });
});

router.get('/me', requireAuth, async (req, res) => {
  const user = await User.findById(req.userId);
  res.json({ user: selfProfile(user) });
});

export default router;
