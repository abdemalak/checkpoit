import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.js';
import { optionalHttpUrl, validate } from '../middleware/validate.js';
import { User } from '../models/User.js';
import { badRequest, notFound } from '../utils/httpError.js';
import { selfProfile, userProfile } from '../utils/serialize.js';

const router = Router();
router.use(requireAuth);

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// GET /api/users?q=sara — search people by name or username
router.get('/', async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 50);
  if (!q) return res.json({ users: [] });

  const pattern = new RegExp(escapeRegex(q), 'i');
  const users = await User.find({ $or: [{ username: pattern }, { name: pattern }] })
    .sort({ username: 1 })
    .limit(20);
  res.json({ users: users.map((user) => userProfile(user, req.userId)) });
});

// GET /api/users/suggestions — people the current user doesn't follow yet
router.get('/suggestions', async (req, res) => {
  const me = await User.findById(req.userId).select('following');
  const users = await User.find({ _id: { $nin: [req.userId, ...me.following] } })
    .sort({ createdAt: -1 })
    .limit(5);
  res.json({ users: users.map((user) => userProfile(user, req.userId)) });
});

const profileSchema = z.object({
  name: z.string().trim().min(1, 'Name is required').max(60, 'Name must be 60 characters or less').optional(),
  bio: z.string().trim().max(160, 'Bio must be 160 characters or less').optional(),
  location: z.string().trim().max(60, 'Location must be 60 characters or less').optional(),
  avatar: optionalHttpUrl.optional(),
  website: optionalHttpUrl.optional(),
});

// PATCH /api/users/me — update the signed-in user's profile
router.patch('/me', validate(profileSchema), async (req, res) => {
  const user = await User.findById(req.userId);
  Object.assign(user, req.body);
  await user.save();
  res.json({ user: selfProfile(user) });
});

// GET /api/users/:username — a public profile
router.get('/:username', async (req, res) => {
  const user = await User.findOne({ username: req.params.username.toLowerCase() });
  if (!user) throw notFound('User not found');
  res.json({ user: userProfile(user, req.userId) });
});

const listConnections = (field) => async (req, res) => {
  const user = await User.findOne({ username: req.params.username.toLowerCase() })
    .select(field)
    .populate(field);
  if (!user) throw notFound('User not found');
  res.json({ users: user[field].map((person) => userProfile(person, req.userId)) });
};

router.get('/:username/followers', listConnections('followers'));
router.get('/:username/following', listConnections('following'));

async function loadFollowTarget(req) {
  if (req.params.id === req.userId) throw badRequest("You can't follow yourself");
  const target = await User.findById(req.params.id).select('_id');
  if (!target) throw notFound('User not found');
  return target;
}

async function followersCount(userId) {
  const user = await User.findById(userId).select('followers');
  return user.followers.length;
}

// POST /api/users/:id/follow — follow a user (idempotent)
router.post('/:id/follow', async (req, res) => {
  const target = await loadFollowTarget(req);
  await Promise.all([
    User.updateOne({ _id: target._id }, { $addToSet: { followers: req.userId } }),
    User.updateOne({ _id: req.userId }, { $addToSet: { following: target._id } }),
  ]);
  res.json({ following: true, followersCount: await followersCount(target._id) });
});

// DELETE /api/users/:id/follow — unfollow a user (idempotent)
router.delete('/:id/follow', async (req, res) => {
  const target = await loadFollowTarget(req);
  await Promise.all([
    User.updateOne({ _id: target._id }, { $pull: { followers: req.userId } }),
    User.updateOne({ _id: req.userId }, { $pull: { following: target._id } }),
  ]);
  res.json({ following: false, followersCount: await followersCount(target._id) });
});

export default router;
