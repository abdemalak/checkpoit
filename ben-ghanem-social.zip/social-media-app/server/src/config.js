import dotenv from 'dotenv';

dotenv.config({ quiet: true });

const env = process.env.NODE_ENV || 'development';

// `--port 5050` on the command line wins over the PORT variable. The dev script
// uses it so the API always matches the Vite proxy, even if PORT is set in your shell.
const portFlag = process.argv.indexOf('--port');
const cliPort = portFlag > -1 ? Number(process.argv[portFlag + 1]) : 0;

export const config = {
  env,
  isProd: env === 'production',
  isTest: env === 'test' || Boolean(process.env.VITEST),
  port: cliPort || Number(process.env.PORT) || 5050,
  // Leave MONGO_URI empty in development to use a local MongoDB that starts automatically.
  mongoUri: process.env.MONGO_URI || '',
  jwtSecret: process.env.JWT_SECRET || 'dev-only-secret-change-me',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  // Comma-separated list of origins allowed to call the API (only needed when the
  // front end is hosted on a different domain than the API).
  clientOrigins: (process.env.CLIENT_ORIGIN || 'http://localhost:5173')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean),
};

if (config.isProd) {
  const missing = ['MONGO_URI', 'JWT_SECRET'].filter((key) => !process.env[key]);
  if (missing.length) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }
}
