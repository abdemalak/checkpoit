import http from 'node:http';
import { createApp } from './app.js';
import { config } from './config.js';
import { connectDB, disconnectDB, LOCAL_DB_DIR } from './db.js';
import { seedIfEmpty } from './seed.js';
import { closeSocket, initSocket } from './socket.js';

const { usingLocalDb } = await connectDB(config.mongoUri);

if (usingLocalDb) {
  console.log(`MONGO_URI is not set: using a local development database stored in ${LOCAL_DB_DIR}`);
  if (await seedIfEmpty()) {
    console.log('Added demo data. Log in with username "demo" and password "password123".');
  }
}

const app = createApp();
const server = http.createServer(app);
initSocket(server);

server.listen(config.port, () => {
  console.log(`API ready on http://localhost:${config.port} (${config.env})`);
});

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`${signal} received, shutting down...`);
  server.close();
  await closeSocket();
  await disconnectDB().catch(() => {});
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
