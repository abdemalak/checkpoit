import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import mongoose from 'mongoose';

let localServer = null;

// Where the automatic development database keeps its files. It lives in a short
// folder in your home directory because MongoDB on Windows can't use very long paths.
export const LOCAL_DB_DIR = path.resolve(
  process.env.LOCAL_DB_DIR || path.join(os.homedir(), '.ben-ghanem-dev', 'db'),
);

/**
 * Connects to MongoDB. When no URI is given (local development), a MongoDB
 * instance is started automatically and its data is kept in LOCAL_DB_DIR so it
 * survives restarts.
 */
export async function connectDB(uri) {
  let target = uri;

  if (!target) {
    const { MongoMemoryServer } = await import('mongodb-memory-server');
    const dbPath = LOCAL_DB_DIR;
    fs.mkdirSync(dbPath, { recursive: true });
    localServer = await MongoMemoryServer.create({
      instance: { dbPath, storageEngine: 'wiredTiger' },
    });
    target = localServer.getUri('benghanem');
  }

  await mongoose.connect(target);
  return { usingLocalDb: Boolean(localServer) };
}

export async function disconnectDB() {
  await mongoose.disconnect();
  if (localServer) {
    await localServer.stop({ doCleanup: false });
    localServer = null;
  }
}
