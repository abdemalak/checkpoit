import { User } from '../models/User.js';
import { unauthorized } from '../utils/httpError.js';
import { verifyToken } from '../utils/token.js';

/** Requires a valid "Authorization: Bearer <token>" header and sets req.userId. */
export async function requireAuth(req, res, next) {
  const [scheme, token] = (req.get('authorization') || '').split(' ');
  if (scheme !== 'Bearer' || !token) throw unauthorized('Please log in to continue');

  let payload;
  try {
    payload = verifyToken(token);
  } catch {
    throw unauthorized('Your session has expired, please log in again');
  }

  if (!(await User.exists({ _id: payload.sub }))) {
    throw unauthorized('This account no longer exists');
  }

  req.userId = String(payload.sub);
  next();
}
