import { z } from 'zod';
import mongoose from 'mongoose';
import { badRequest } from '../utils/httpError.js';

/** Validates req.body against a zod schema and replaces it with the parsed (trimmed) data. */
export const validate = (schema) => (req, res, next) => {
  const result = schema.safeParse(req.body ?? {});
  if (!result.success) {
    const details = result.error.issues.map((issue) => ({
      field: issue.path.join('.'),
      message: issue.message,
    }));
    throw badRequest(details[0]?.message || 'Invalid request', details);
  }
  req.body = result.data;
  next();
};

/** An optional http(s) URL; the empty string clears the field. */
export const optionalHttpUrl = z
  .string()
  .trim()
  .max(500, 'URL is too long')
  .refine((value) => value === '' || /^https?:\/\/[^\s]+$/i.test(value), {
    message: 'Must be a link starting with http:// or https://',
  });

export const objectId = z
  .string()
  .refine((value) => mongoose.isValidObjectId(value), { message: 'Invalid id' });
