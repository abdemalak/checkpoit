import mongoose from 'mongoose';
import { badRequest } from './httpError.js';

/**
 * Cursor pagination over (createdAt, _id), newest first. A cursor looks like
 * "2026-11-17T10:00:00.000Z_<objectId>" and points at the last item already shown.
 */
export function cursorFilter(cursor) {
  if (!cursor) return {};
  const [iso, id] = String(cursor).split('_');
  const date = new Date(iso);
  if (Number.isNaN(date.getTime()) || !mongoose.isValidObjectId(id)) {
    throw badRequest('Invalid pagination cursor');
  }
  const objectId = new mongoose.Types.ObjectId(id);
  return { $or: [{ createdAt: { $lt: date } }, { createdAt: date, _id: { $lt: objectId } }] };
}

export function makeCursor(doc) {
  return `${doc.createdAt.toISOString()}_${doc._id}`;
}

export function pageLimit(value, fallback, max = 50) {
  const n = Number.parseInt(value, 10);
  if (!Number.isFinite(n) || n < 1) return fallback;
  return Math.min(n, max);
}

/** Runs a newest-first query for one page and returns the items plus the next cursor. */
export async function paginate(Model, filter, { cursor, limit, populate }) {
  let query = Model.find({ ...filter, ...cursorFilter(cursor) })
    .sort({ createdAt: -1, _id: -1 })
    .limit(limit + 1);
  if (populate) query = populate(query);
  const docs = await query;
  const hasMore = docs.length > limit;
  const items = docs.slice(0, limit);
  return { items, nextCursor: hasMore ? makeCursor(items.at(-1)) : null };
}
