// Shapes database documents into the JSON the client receives, so that
// private fields (password, email, raw follower lists) never leak by accident.

const idOf = (value) => String(value?._id ?? value);

export function userSummary(user) {
  if (!user) return null;
  return {
    id: idOf(user),
    name: user.name,
    username: user.username,
    avatar: user.avatar || '',
  };
}

export function userProfile(user, viewerId) {
  const followers = (user.followers || []).map(String);
  return {
    ...userSummary(user),
    bio: user.bio || '',
    location: user.location || '',
    website: user.website || '',
    createdAt: user.createdAt,
    followersCount: followers.length,
    followingCount: (user.following || []).length,
    isFollowing: viewerId ? followers.includes(String(viewerId)) : false,
    isMe: viewerId ? idOf(user) === String(viewerId) : false,
  };
}

/** The signed-in user's own profile, which also includes their email. */
export function selfProfile(user) {
  return { ...userProfile(user, user._id), email: user.email };
}

export function serializeComment(comment) {
  return {
    id: idOf(comment),
    author: userSummary(comment.author),
    text: comment.text,
    createdAt: comment.createdAt,
  };
}

export function serializePost(post, viewerId) {
  const likes = (post.likes || []).map(String);
  const comments = post.comments || [];
  return {
    id: idOf(post),
    author: userSummary(post.author),
    text: post.text,
    image: post.image || '',
    createdAt: post.createdAt,
    likesCount: likes.length,
    liked: likes.includes(String(viewerId)),
    commentsCount: comments.length,
    comments: comments.map(serializeComment),
  };
}

export function serializeMessage(message) {
  return {
    id: idOf(message),
    conversationId: idOf(message.conversation),
    sender: idOf(message.sender),
    text: message.text,
    createdAt: message.createdAt,
    readBy: (message.readBy || []).map(String),
  };
}
