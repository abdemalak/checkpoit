import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';

let mongo;
let app;
let counter = 0;

beforeAll(async () => {
  mongo = await MongoMemoryServer.create();
  await mongoose.connect(mongo.getUri('benghanem-test'));
  await mongoose.connection.syncIndexes();
  app = createApp();
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongo?.stop();
});

async function signUp(overrides = {}) {
  counter += 1;
  const body = {
    name: `Test User ${counter}`,
    username: `user${counter}`,
    email: `user${counter}@test.dev`,
    password: 'secret123',
    ...overrides,
  };
  const res = await request(app).post('/api/auth/register').send(body);
  expect(res.status, JSON.stringify(res.body)).toBe(201);
  return { ...res.body, auth: { Authorization: `Bearer ${res.body.token}` } };
}

describe('authentication', () => {
  it('registers a user and never returns the password', async () => {
    const { token, user } = await signUp({ username: 'Alice_01', email: 'ALICE@test.dev' });
    expect(token).toBeTypeOf('string');
    expect(user).toMatchObject({ username: 'alice_01', email: 'alice@test.dev', followersCount: 0 });
    expect(user.password).toBeUndefined();
  });

  it('rejects duplicate usernames and emails', async () => {
    await signUp({ username: 'taken', email: 'taken@test.dev' });
    const sameName = await request(app)
      .post('/api/auth/register')
      .send({ name: 'X', username: 'taken', email: 'new@test.dev', password: 'secret123' });
    expect(sameName.status).toBe(409);
    expect(sameName.body.error).toMatch(/username/i);

    const sameEmail = await request(app)
      .post('/api/auth/register')
      .send({ name: 'X', username: 'fresh', email: 'taken@test.dev', password: 'secret123' });
    expect(sameEmail.status).toBe(409);
    expect(sameEmail.body.error).toMatch(/email/i);
  });

  it('validates input with readable messages', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: '', username: 'a', email: 'nope', password: '1' });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('Name is required');
    expect(res.body.details.map((d) => d.field)).toEqual(['name', 'username', 'email', 'password']);
  });

  it('logs in with username or email and rejects a wrong password', async () => {
    await signUp({ username: 'bob', email: 'bob@test.dev' });
    const byName = await request(app).post('/api/auth/login').send({ identifier: 'BOB', password: 'secret123' });
    expect(byName.status).toBe(200);
    expect(byName.body.user.username).toBe('bob');

    const byEmail = await request(app).post('/api/auth/login').send({ identifier: 'bob@test.dev', password: 'secret123' });
    expect(byEmail.status).toBe(200);

    const wrong = await request(app).post('/api/auth/login').send({ identifier: 'bob', password: 'nope-nope' });
    expect(wrong.status).toBe(401);
  });

  it('protects private routes', async () => {
    expect((await request(app).get('/api/auth/me')).status).toBe(401);
    expect((await request(app).get('/api/auth/me').set('Authorization', 'Bearer garbage')).status).toBe(401);

    const { auth } = await signUp();
    const me = await request(app).get('/api/auth/me').set(auth);
    expect(me.status).toBe(200);
    expect(me.body.user.isMe).toBe(true);
  });
});

describe('profiles and following', () => {
  it('updates the profile and rejects unsafe links', async () => {
    const { auth } = await signUp();
    const ok = await request(app)
      .patch('/api/users/me')
      .set(auth)
      .send({ bio: '  Hello there  ', website: 'https://example.com', location: 'Tunis' });
    expect(ok.status).toBe(200);
    expect(ok.body.user).toMatchObject({ bio: 'Hello there', website: 'https://example.com', location: 'Tunis' });

    const bad = await request(app).patch('/api/users/me').set(auth).send({ website: 'javascript:alert(1)' });
    expect(bad.status).toBe(400);
  });

  it('follows and unfollows, keeping counts in sync', async () => {
    const a = await signUp();
    const b = await signUp();

    const follow = await request(app).post(`/api/users/${b.user.id}/follow`).set(a.auth);
    expect(follow.body).toEqual({ following: true, followersCount: 1 });
    // Following twice is harmless.
    await request(app).post(`/api/users/${b.user.id}/follow`).set(a.auth);

    const profile = await request(app).get(`/api/users/${b.user.username}`).set(a.auth);
    expect(profile.body.user).toMatchObject({ followersCount: 1, isFollowing: true, isMe: false });

    const followers = await request(app).get(`/api/users/${b.user.username}/followers`).set(a.auth);
    expect(followers.body.users.map((u) => u.id)).toEqual([a.user.id]);

    const unfollow = await request(app).delete(`/api/users/${b.user.id}/follow`).set(a.auth);
    expect(unfollow.body).toEqual({ following: false, followersCount: 0 });

    const self = await request(app).post(`/api/users/${a.user.id}/follow`).set(a.auth);
    expect(self.status).toBe(400);
  });

  it('searches people and 404s unknown profiles', async () => {
    const a = await signUp({ name: 'Zeynep Searchable', username: 'zeynep' });
    const res = await request(app).get('/api/users?q=searchable').set(a.auth);
    expect(res.body.users.map((u) => u.username)).toContain('zeynep');

    // Regex characters in the query are treated literally.
    expect((await request(app).get('/api/users?q=.*').set(a.auth)).status).toBe(200);
    expect((await request(app).get('/api/users/nobody_here').set(a.auth)).status).toBe(404);
  });
});

describe('posts', () => {
  it('builds a feed from the people you follow', async () => {
    const me = await signUp();
    const friend = await signUp();
    const stranger = await signUp();
    await request(app).post(`/api/users/${friend.user.id}/follow`).set(me.auth);

    await request(app).post('/api/posts').set(me.auth).send({ text: 'my post' });
    await request(app).post('/api/posts').set(friend.auth).send({ text: 'friend post' });
    await request(app).post('/api/posts').set(stranger.auth).send({ text: 'stranger post' });

    const feed = await request(app).get('/api/posts/feed').set(me.auth);
    expect(feed.body.posts.map((p) => p.text)).toEqual(['friend post', 'my post']);

    const explore = await request(app).get('/api/posts/explore').set(me.auth);
    expect(explore.body.posts.map((p) => p.text)).toContain('stranger post');
  });

  it('paginates with a cursor without skipping or repeating posts', async () => {
    const author = await signUp();
    for (let i = 1; i <= 5; i += 1) {
      await request(app).post('/api/posts').set(author.auth).send({ text: `post ${i}` });
    }
    const seen = [];
    let cursor = '';
    do {
      const res = await request(app)
        .get(`/api/posts/user/${author.user.id}?limit=2${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`)
        .set(author.auth);
      seen.push(...res.body.posts.map((p) => p.text));
      cursor = res.body.nextCursor;
    } while (cursor);
    expect(seen).toEqual(['post 5', 'post 4', 'post 3', 'post 2', 'post 1']);
  });

  it('rejects empty posts', async () => {
    const { auth } = await signUp();
    const res = await request(app).post('/api/posts').set(auth).send({ text: '   ' });
    expect(res.status).toBe(400);
  });

  it('likes, comments and enforces ownership on delete', async () => {
    const author = await signUp();
    const reader = await signUp();
    const { body } = await request(app).post('/api/posts').set(author.auth).send({ text: 'hello world' });
    const postId = body.post.id;

    const like = await request(app).post(`/api/posts/${postId}/like`).set(reader.auth);
    expect(like.body).toEqual({ liked: true, likesCount: 1 });
    const unlike = await request(app).delete(`/api/posts/${postId}/like`).set(reader.auth);
    expect(unlike.body).toEqual({ liked: false, likesCount: 0 });

    const comment = await request(app).post(`/api/posts/${postId}/comments`).set(reader.auth).send({ text: 'Nice!' });
    expect(comment.status).toBe(201);
    expect(comment.body.comment).toMatchObject({ text: 'Nice!', author: { username: reader.user.username } });

    const post = await request(app).get(`/api/posts/${postId}`).set(reader.auth);
    expect(post.body.post).toMatchObject({ commentsCount: 1, likesCount: 0, liked: false });

    // The post author may remove comments on their post.
    const removeComment = await request(app)
      .delete(`/api/posts/${postId}/comments/${comment.body.comment.id}`)
      .set(author.auth);
    expect(removeComment.status).toBe(204);

    expect((await request(app).delete(`/api/posts/${postId}`).set(reader.auth)).status).toBe(403);
    expect((await request(app).delete(`/api/posts/${postId}`).set(author.auth)).status).toBe(204);
    expect((await request(app).get(`/api/posts/${postId}`).set(author.auth)).status).toBe(404);
    expect((await request(app).get('/api/posts/not-an-id').set(author.auth)).status).toBe(404);
  });
});

describe('messaging', () => {
  it('opens one conversation per pair, sends messages and tracks unread counts', async () => {
    const alice = await signUp();
    const bob = await signUp();
    const eve = await signUp();

    const open = await request(app).post('/api/conversations').set(alice.auth).send({ userId: bob.user.id });
    expect(open.status).toBe(201);
    const conversationId = open.body.conversation.id;
    expect(open.body.conversation.otherUser.username).toBe(bob.user.username);

    // Bob opening a chat with Alice gets the same conversation.
    const reopen = await request(app).post('/api/conversations').set(bob.auth).send({ userId: alice.user.id });
    expect(reopen.status).toBe(200);
    expect(reopen.body.conversation.id).toBe(conversationId);

    await request(app).post(`/api/conversations/${conversationId}/messages`).set(alice.auth).send({ text: 'Hi Bob' });
    await request(app).post(`/api/conversations/${conversationId}/messages`).set(alice.auth).send({ text: 'Are you there?' });

    const unread = await request(app).get('/api/conversations/unread-count').set(bob.auth);
    expect(unread.body.count).toBe(2);

    const inbox = await request(app).get('/api/conversations').set(bob.auth);
    expect(inbox.body.conversations[0]).toMatchObject({
      id: conversationId,
      unreadCount: 2,
      lastMessage: { text: 'Are you there?' },
    });

    const messages = await request(app).get(`/api/conversations/${conversationId}/messages`).set(bob.auth);
    expect(messages.body.messages.map((m) => m.text)).toEqual(['Hi Bob', 'Are you there?']);

    const read = await request(app).post(`/api/conversations/${conversationId}/read`).set(bob.auth);
    expect(read.body.updated).toBe(2);
    expect((await request(app).get('/api/conversations/unread-count').set(bob.auth)).body.count).toBe(0);

    // Outsiders can't read or post.
    expect((await request(app).get(`/api/conversations/${conversationId}/messages`).set(eve.auth)).status).toBe(404);
    expect(
      (await request(app).post(`/api/conversations/${conversationId}/messages`).set(eve.auth).send({ text: 'hi' })).status,
    ).toBe(404);
  });

  it('refuses to message yourself or send an empty message', async () => {
    const alice = await signUp();
    const bob = await signUp();
    expect((await request(app).post('/api/conversations').set(alice.auth).send({ userId: alice.user.id })).status).toBe(400);

    const { body } = await request(app).post('/api/conversations').set(alice.auth).send({ userId: bob.user.id });
    const empty = await request(app).post(`/api/conversations/${body.conversation.id}/messages`).set(alice.auth).send({ text: '  ' });
    expect(empty.status).toBe(400);
  });
});

describe('misc', () => {
  it('reports health and 404s unknown API routes as JSON', async () => {
    expect((await request(app).get('/api/health')).body.status).toBe('ok');
    const missing = await request(app).get('/api/nope');
    expect(missing.status).toBe(404);
    expect(missing.body.error).toBeDefined();
  });

  it('handles malformed JSON', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .set('Content-Type', 'application/json')
      .send('{"identifier":');
    expect(res.status).toBe(400);
  });
});
